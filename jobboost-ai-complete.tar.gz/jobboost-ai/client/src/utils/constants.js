export const APP_NAME = 'JobBoost AI';

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  UPLOAD: '/upload',
  ANALYSIS: '/analysis/:id',
  RESULTS: '/results/:id',
  CV_OPTIMIZED: '/cv/:id',
  HISTORY: '/history',
};

export const ANALYSIS_STEPS = [
  {
    id: 1,
    name: 'Analyse des compétences',
    description: 'Extraction et analyse de vos compétences',
  },
  {
    id: 2,
    name: 'Recherche de métiers',
    description: 'Identification des métiers adaptés à votre profil',
  },
  {
    id: 3,
    name: 'Calcul de compatibilité',
    description: 'Évaluation de votre compatibilité avec chaque métier',
  },
  {
    id: 4,
    name: 'Génération du CV',
    description: 'Optimisation de votre CV pour les métiers ciblés',
  },
];

export const ANALYSIS_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  TEXT_EXTRACTED: 'text_extracted',
  ANALYZING_SKILLS: 'analyzing_skills',
  SKILLS_ANALYZED: 'skills_analyzed',
  RECOMMENDING_JOBS: 'recommending_jobs',
  JOBS_RECOMMENDED: 'jobs_recommended',
  COMPLETED: 'completed',
  FAILED: 'failed',
};

export const ANALYSIS_STATUS_LABELS = {
  [ANALYSIS_STATUS.PENDING]: 'En attente',
  [ANALYSIS_STATUS.PROCESSING]: 'Traitement en cours',
  [ANALYSIS_STATUS.TEXT_EXTRACTED]: 'Texte extrait',
  [ANALYSIS_STATUS.ANALYZING_SKILLS]: 'Analyse des compétences',
  [ANALYSIS_STATUS.SKILLS_ANALYZED]: 'Compétences analysées',
  [ANALYSIS_STATUS.RECOMMENDING_JOBS]: 'Recherche de métiers',
  [ANALYSIS_STATUS.JOBS_RECOMMENDED]: 'Métiers recommandés',
  [ANALYSIS_STATUS.COMPLETED]: 'Analyse terminée',
  [ANALYSIS_STATUS.FAILED]: 'Échec de l\'analyse',
};

export const FILE_TYPES = {
  PDF: 'application/pdf',
  DOCX: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

export const TESTIMONIALS = [
  {
    id: 1,
    name: 'Marie Dubois',
    role: 'Développeuse Web',
    image: 'https://i.pravatar.cc/150?img=1',
    content: 'JobBoost AI m\'a aidée à identifier de nouvelles opportunités de carrière. Mon CV optimisé a doublé mes entretiens !',
    rating: 5,
  },
  {
    id: 2,
    name: 'Thomas Martin',
    role: 'Data Analyst',
    image: 'https://i.pravatar.cc/150?img=2',
    content: 'L\'analyse IA est impressionnante. J\'ai découvert des métiers auxquels je n\'avais jamais pensé et qui correspondent parfaitement à mes compétences.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Sophie Bernard',
    role: 'Chef de Projet',
    image: 'https://i.pravatar.cc/150?img=3',
    content: 'Interface intuitive et résultats précis. J\'ai trouvé ma nouvelle voie professionnelle grâce à JobBoost AI.',
    rating: 5,
  },
];

export const FAQ_ITEMS = [
  {
    question: 'Comment fonctionne JobBoost AI ?',
    answer: 'JobBoost AI analyse votre CV avec une intelligence artificielle avancée. Elle extrait vos compétences, expériences et formations, puis recommande les métiers les plus adaptés à votre profil avec un score de compatibilité. Ensuite, elle génère une version optimisée de votre CV.',
  },
  {
    question: 'Mes données sont-elles sécurisées ?',
    answer: 'Absolument. Vos données sont cryptées et stockées de manière sécurisée. Nous ne partageons jamais vos informations avec des tiers. Vous pouvez supprimer vos données à tout moment.',
  },
  {
    question: 'Quels formats de CV sont acceptés ?',
    answer: 'Nous acceptons les fichiers PDF et DOCX d\'une taille maximale de 10 MB. Votre CV doit contenir du texte lisible (pas uniquement des images).',
  },
  {
    question: 'Combien de crédits ai-je ?',
    answer: 'Chaque utilisateur reçoit 5 crédits gratuits à l\'inscription. Chaque analyse consomme 1 crédit. Vous pouvez acheter des crédits supplémentaires ou passer à un plan premium pour des analyses illimitées.',
  },
  {
    question: 'Puis-je télécharger mon CV optimisé ?',
    answer: 'Oui ! Une fois l\'analyse terminée, vous pouvez télécharger votre CV optimisé au format PDF ou HTML. Vous pouvez également comparer votre CV original avec la version optimisée.',
  },
  {
    question: 'L\'analyse fonctionne-t-elle pour tous les secteurs ?',
    answer: 'Oui, JobBoost AI analyse tous types de CV, quels que soient le secteur d\'activité et le niveau d\'expérience. Notre IA est formée sur une large base de données de métiers et de compétences.',
  },
];

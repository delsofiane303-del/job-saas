import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export const extractTextFromPDF = async (file) => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(' ');
      fullText += pageText + '\n';
    }
    
    return {
      text: fullText,
      numPages: pdf.numPages,
      success: true
    };
  } catch (error) {
    console.error('Error extracting PDF text:', error);
    return {
      text: '',
      numPages: 0,
      success: false,
      error: error.message
    };
  }
};

export const validatePDFFile = (file) => {
  const maxSize = 10 * 1024 * 1024;
  
  if (!file) {
    return { valid: false, error: 'Aucun fichier sélectionné' };
  }
  
  if (file.type !== 'application/pdf' && 
      file.type !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    return { valid: false, error: 'Format de fichier non supporté. Utilisez PDF ou DOCX.' };
  }
  
  if (file.size > maxSize) {
    return { valid: false, error: 'Le fichier est trop volumineux. Taille maximale: 10 MB.' };
  }
  
  return { valid: true };
};

export const renderPDFPage = async (file, pageNumber = 1, canvas) => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const page = await pdf.getPage(pageNumber);
    
    const viewport = page.getViewport({ scale: 1.5 });
    const context = canvas.getContext('2d');
    
    canvas.height = viewport.height;
    canvas.width = viewport.width;
    
    await page.render({
      canvasContext: context,
      viewport: viewport
    }).promise;
    
    return { success: true, totalPages: pdf.numPages };
  } catch (error) {
    console.error('Error rendering PDF page:', error);
    return { success: false, error: error.message };
  }
};

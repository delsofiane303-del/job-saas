import { ClerkProvider, SignIn, SignUp, useUser, useAuth } from '@clerk/clerk-react';

const CLERK_PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

if (!CLERK_PUBLISHABLE_KEY) {
  throw new Error('Missing Clerk Publishable Key');
}

export { ClerkProvider, SignIn, SignUp, useUser, useAuth };
export default CLERK_PUBLISHABLE_KEY;

import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  async (config) => {
    const token = await window.Clerk?.session?.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  syncUser: (userId) => api.post('/auth/sync', { userId }),
  getCurrentUser: () => api.get('/auth/me'),
  getCredits: () => api.get('/auth/credits'),
};

export const uploadAPI = {
  uploadCV: (formData) => api.post('/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  getUploadStatus: (analysisId) => api.get(`/upload/status/${analysisId}`),
};

export const analysisAPI = {
  startAnalysis: (analysisId) => api.post('/analysis/start', { analysisId }),
  getAnalysisStatus: (analysisId) => api.get(`/analysis/status/${analysisId}`),
  getAnalysisResults: (analysisId) => api.get(`/analysis/results/${analysisId}`),
};

export const cvAPI = {
  generateCV: (analysisId, targetJob) => api.post('/cv/generate', { analysisId, targetJob }),
  getCVStatus: (analysisId) => api.get(`/cv/status/${analysisId}`),
  downloadCV: (filename) => `${API_BASE_URL}/cv/download/${filename}`,
  getComparison: (analysisId) => api.get(`/cv/comparison/${analysisId}`),
};

export const historyAPI = {
  getHistory: (limit = 50) => api.get('/history', { params: { limit } }),
  getAnalysesList: (limit = 20, offset = 0) => 
    api.get('/history/analyses', { params: { limit, offset } }),
  deleteAnalysis: (analysisId) => api.delete(`/history/analyses/${analysisId}`),
  getStats: () => api.get('/history/stats'),
};

export default api;

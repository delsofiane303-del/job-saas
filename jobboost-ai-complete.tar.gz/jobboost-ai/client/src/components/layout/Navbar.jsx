import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { useUser, useAuth } from '@clerk/clerk-react';
import { useApp } from '../../context/AppContext';
import Button from '../common/Button';
import { fadeInDown } from '../../utils/animations';

const Navbar = () => {
  const { isSignedIn } = useAuth();
  const { user } = useUser();
  const { credits } = useApp();
  const navigate = useNavigate();

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-30 glass border-b border-white/10"
      initial="initial"
      animate="animate"
      variants={fadeInDown}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-blue rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <span className="text-xl font-bold text-white">JobBoost AI</span>
          </Link>

          {/* Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link to="/#how-it-works" className="text-dark-300 hover:text-white transition-colors">
              Fonctionnement
            </Link>
            <Link to="/#testimonials" className="text-dark-300 hover:text-white transition-colors">
              Témoignages
            </Link>
            <Link to="/#faq" className="text-dark-300 hover:text-white transition-colors">
              FAQ
            </Link>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            {isSignedIn ? (
              <>
                {/* Credits */}
                <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-dark-800 rounded-lg border border-dark-600">
                  <svg className="w-5 h-5 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-white font-medium">{credits ?? '...'}</span>
                </div>

                {/* User */}
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => navigate('/dashboard')}
                  icon={
                    user?.imageUrl ? (
                      <img src={user.imageUrl} alt="Profile" className="w-6 h-6 rounded-full" />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-primary-600 flex items-center justify-center text-white text-sm">
                        {user?.firstName?.[0] || 'U'}
                      </div>
                    )
                  }
                >
                  Dashboard
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/login')}
                >
                  Connexion
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => navigate('/login')}
                >
                  Commencer
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;

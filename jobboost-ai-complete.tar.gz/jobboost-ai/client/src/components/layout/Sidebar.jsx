import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { slideInLeft } from '../../utils/animations';

const Sidebar = () => {
  const location = useLocation();

  const menuItems = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
    },
    {
      name: 'Upload CV',
      path: '/upload',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
      ),
    },
    {
      name: 'Historique',
      path: '/history',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <motion.aside
      className="fixed left-0 top-16 bottom-0 w-64 bg-dark-900 border-r border-dark-700 p-4"
      initial="initial"
      animate="animate"
      variants={slideInLeft}
    >
      <nav className="space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`
              flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200
              ${
                isActive(item.path)
                  ? 'bg-primary-600 text-white shadow-glow-sm'
                  : 'text-dark-300 hover:bg-dark-800 hover:text-white'
              }
            `}
          >
            {item.icon}
            <span className="font-medium">{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Bottom Section */}
      <div className="absolute bottom-8 left-4 right-4">
        <div className="p-4 bg-dark-800 border border-dark-700 rounded-lg">
          <p className="text-sm text-dark-400 mb-2">Besoin d'aide ?</p>
          <a
            href="mailto:support@jobboost.ai"
            className="text-sm text-primary-500 hover:text-primary-400 transition-colors"
          >
            Contacter le support
          </a>
        </div>
      </div>
    </motion.aside>
  );
};

export default Sidebar;

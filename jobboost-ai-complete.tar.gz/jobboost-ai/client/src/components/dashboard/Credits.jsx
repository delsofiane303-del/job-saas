import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import Card from '../common/Card';
import Button from '../common/Button';
import { fadeInUp } from '../../utils/animations';

const Credits = () => {
  const { credits, user } = useApp();

  const handleBuyCredits = () => {
    // TODO: Implémenter l'achat de crédits
    alert('Fonctionnalité d\'achat de crédits à venir !');
  };

  const getCreditColor = () => {
    if (credits === null) return 'text-dark-400';
    if (credits >= 5) return 'text-green-500';
    if (credits >= 2) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getCreditMessage = () => {
    if (credits === null) return 'Chargement...';
    if (credits === 0) return 'Vous n\'avez plus de crédits';
    if (credits === 1) return 'Il vous reste 1 crédit';
    return `Il vous reste ${credits} crédits`;
  };

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      <Card className="bg-gradient-to-br from-primary-600/10 to-blue-600/10 border-primary-500/30">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <svg className="w-8 h-8 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <h3 className="text-lg font-semibold text-white">Crédits IA</h3>
                <p className="text-sm text-dark-400">1 crédit = 1 analyse complète</p>
              </div>
            </div>

            <div className={`text-2xl font-bold ${getCreditColor()} mb-1`}>
              {getCreditMessage()}
            </div>

            <p className="text-sm text-dark-400">
              Plan actuel: <span className="text-white font-medium">{user?.plan || 'Gratuit'}</span>
            </p>
          </div>

          <div>
            <Button
              variant="primary"
              size="sm"
              onClick={handleBuyCredits}
              disabled={credits === null}
            >
              Acheter des crédits
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        {credits !== null && (
          <div className="mt-4">
            <div className="h-2 bg-dark-700 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-blue"
                initial={{ width: 0 }}
                animate={{ width: `${(credits / 10) * 100}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              />
            </div>
            <p className="text-xs text-dark-500 mt-1 text-right">
              {credits} / 10 crédits utilisés ce mois
            </p>
          </div>
        )}
      </Card>
    </motion.div>
  );
};

export default Credits;

import { motion } from 'framer-motion';
import { useUser } from '@clerk/clerk-react';
import { useApp } from '../../context/AppContext';
import Card from '../common/Card';
import { fadeInUp } from '../../utils/animations';
import { getInitials } from '../../utils/helpers';

const UserProfile = () => {
  const { user } = useUser();
  const { credits } = useApp();

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      <Card>
        <div className="flex items-center gap-4">
          {/* Avatar */}
          {user?.imageUrl ? (
            <img
              src={user.imageUrl}
              alt={user.fullName || 'User'}
              className="w-16 h-16 rounded-full ring-2 ring-primary-500"
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-primary-600 flex items-center justify-center text-white text-xl font-bold ring-2 ring-primary-500">
              {getInitials(user?.fullName || 'User')}
            </div>
          )}

          {/* Info */}
          <div className="flex-1">
            <h2 className="text-xl font-bold text-white">
              {user?.fullName || 'Utilisateur'}
            </h2>
            <p className="text-dark-400 text-sm">
              {user?.primaryEmailAddress?.emailAddress}
            </p>
          </div>

          {/* Credits Badge */}
          <div className="text-right">
            <div className="text-3xl font-bold text-gradient">{credits ?? '...'}</div>
            <p className="text-dark-400 text-sm">Crédits restants</p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default UserProfile;

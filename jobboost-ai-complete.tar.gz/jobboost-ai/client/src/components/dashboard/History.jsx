import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { historyAPI } from '../../services/api';
import Card from '../common/Card';
import Button from '../common/Button';
import Loader from '../common/Loader';
import { fadeInUp, staggerContainer, staggerItem } from '../../utils/animations';
import { formatDateTime } from '../../utils/helpers';
import toast from 'react-hot-toast';

const History = () => {
  const navigate = useNavigate();
  const [analyses, setAnalyses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalyses();
  }, []);

  const fetchAnalyses = async () => {
    try {
      setLoading(true);
      const response = await historyAPI.getAnalysesList(5, 0);
      if (response.data.success) {
        setAnalyses(response.data.analyses);
      }
    } catch (error) {
      console.error('Error fetching analyses:', error);
      toast.error('Erreur lors du chargement de l\'historique');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-green-500 bg-green-500/10';
      case 'processing':
      case 'analyzing_skills':
      case 'recommending_jobs':
        return 'text-yellow-500 bg-yellow-500/10';
      case 'failed':
        return 'text-red-500 bg-red-500/10';
      default:
        return 'text-blue-500 bg-blue-500/10';
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      pending: 'En attente',
      processing: 'En cours',
      text_extracted: 'Texte extrait',
      analyzing_skills: 'Analyse...',
      skills_analyzed: 'Analysé',
      recommending_jobs: 'Recherche...',
      jobs_recommended: 'Terminé',
      completed: 'Terminé',
      failed: 'Échec',
    };
    return labels[status] || status;
  };

  if (loading) {
    return (
      <Card>
        <Loader text="Chargement de l'historique..." />
      </Card>
    );
  }

  if (analyses.length === 0) {
    return (
      <motion.div
        initial="initial"
        animate="animate"
        variants={fadeInUp}
      >
        <Card className="text-center py-12">
          <div className="w-16 h-16 bg-dark-700 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-dark-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <p className="text-dark-400 mb-4">Aucune analyse pour le moment</p>
          <Button size="sm" onClick={() => navigate('/upload')}>
            Commencer une analyse
          </Button>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      variants={staggerContainer}
      initial="initial"
      animate="animate"
    >
      <Card>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Analyses récentes</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/history')}
          >
            Voir tout
          </Button>
        </div>

        <div className="space-y-3">
          {analyses.map((analysis, index) => (
            <motion.div
              key={analysis.id}
              variants={staggerItem}
              className="flex items-center justify-between p-4 bg-dark-900 rounded-lg border border-dark-700 hover:border-primary-500/50 transition-all cursor-pointer"
              onClick={() => {
                if (analysis.status === 'completed') {
                  navigate(`/results/${analysis.id}`);
                } else if (analysis.status.includes('analyzing') || analysis.status.includes('recommending')) {
                  navigate(`/analysis/${analysis.id}`);
                }
              }}
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="w-10 h-10 bg-primary-600/10 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">
                    {analysis.original_cv_filename}
                  </p>
                  <p className="text-sm text-dark-400">
                    {formatDateTime(analysis.created_at)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(analysis.status)}`}>
                  {getStatusLabel(analysis.status)}
                </span>

                {analysis.status === 'completed' && (
                  <svg className="w-5 h-5 text-dark-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
};

export default History;

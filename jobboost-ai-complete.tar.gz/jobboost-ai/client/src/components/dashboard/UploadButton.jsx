import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import Card from '../common/Card';
import Button from '../common/Button';
import { scaleIn } from '../../utils/animations';

const UploadButton = () => {
  const navigate = useNavigate();
  const { credits } = useApp();

  const handleUpload = () => {
    if (credits === 0) {
      alert('Vous n\'avez plus de crédits. Achetez-en pour continuer.');
      return;
    }
    navigate('/upload');
  };

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={scaleIn}
    >
      <Card className="text-center py-12 bg-gradient-to-br from-primary-600 to-blue-600 border-none shadow-glow">
        <motion.div
          className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6"
          whileHover={{ scale: 1.1, rotate: 5 }}
          transition={{ duration: 0.3 }}
        >
          <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
          </svg>
        </motion.div>

        <h3 className="text-2xl font-bold text-white mb-3">
          Analysez votre CV
        </h3>
        <p className="text-white/80 mb-6 max-w-md mx-auto">
          Uploadez votre CV et découvrez les métiers qui correspondent à votre profil en quelques minutes.
        </p>

        <Button
          size="lg"
          variant="secondary"
          onClick={handleUpload}
          className="bg-white text-primary-600 hover:bg-gray-100"
          disabled={credits === 0}
        >
          Commencer une analyse
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </Button>

        {credits === 0 && (
          <p className="text-red-200 text-sm mt-4">
            ⚠️ Vous n'avez plus de crédits disponibles
          </p>
        )}
      </Card>
    </motion.div>
  );
};

export default UploadButton;

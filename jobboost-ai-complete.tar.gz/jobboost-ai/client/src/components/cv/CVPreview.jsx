import { motion } from 'framer-motion';
import Card from '../common/Card';
import { fadeInUp } from '../../utils/animations';

const CVPreview = ({ cvData, isOptimized = false }) => {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      <Card className={isOptimized ? 'border-primary-500/30' : ''}>
        <div className="prose prose-invert max-w-none">
          {/* Header */}
          <div className="border-b-2 border-primary-600 pb-4 mb-6">
            <h1 className="text-3xl font-bold text-white mb-2">
              {cvData.name || 'Nom du candidat'}
            </h1>
            {cvData.email && (
              <p className="text-dark-400 text-sm">
                {cvData.email} {cvData.phone && `• ${cvData.phone}`}
              </p>
            )}
          </div>

          {/* Summary */}
          {cvData.summary && (
            <div className="mb-6">
              <h2 className="text-xl font-bold text-primary-500 mb-3">Résumé Professionnel</h2>
              <p className="text-dark-300 leading-relaxed">{cvData.summary}</p>
            </div>
          )}

          {/* Skills */}
          {cvData.skills && (
            <div className="mb-6">
              <h2 className="text-xl font-bold text-primary-500 mb-3">Compétences</h2>
              <div className="grid grid-cols-2 gap-4">
                {cvData.skills.technical && (
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-2">Techniques</h3>
                    <div className="flex flex-wrap gap-2">
                      {cvData.skills.technical.map((skill, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-dark-700 text-dark-300 rounded text-xs"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {cvData.skills.soft && (
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-2">Soft Skills</h3>
                    <div className="flex flex-wrap gap-2">
                      {cvData.skills.soft.map((skill, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-dark-700 text-dark-300 rounded text-xs"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Experience */}
          {cvData.experience && cvData.experience.length > 0 && (
            <div className="mb-6">
              <h2 className="text-xl font-bold text-primary-500 mb-3">Expérience Professionnelle</h2>
              <div className="space-y-4">
                {cvData.experience.map((exp, index) => (
                  <div key={index} className="border-l-2 border-dark-700 pl-4">
                    <h3 className="text-lg font-semibold text-white">{exp.title}</h3>
                    <p className="text-primary-400 text-sm mb-1">{exp.company}</p>
                    <p className="text-dark-500 text-xs mb-2 italic">{exp.duration}</p>
                    <p className="text-dark-300 text-sm">{exp.description}</p>
                    {exp.highlights && exp.highlights.length > 0 && (
                      <ul className="mt-2 space-y-1">
                        {exp.highlights.map((highlight, idx) => (
                          <li key={idx} className="text-dark-300 text-sm flex items-start gap-2">
                            <span className="text-primary-500 mt-1">✓</span>
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {cvData.education && cvData.education.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-primary-500 mb-3">Formation</h2>
              <div className="space-y-3">
                {cvData.education.map((edu, index) => (
                  <div key={index} className="border-l-2 border-dark-700 pl-4">
                    <h3 className="text-lg font-semibold text-white">{edu.degree}</h3>
                    <p className="text-primary-400 text-sm">{edu.institution}</p>
                    <p className="text-dark-500 text-xs italic">{edu.year}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
};

export default CVPreview;

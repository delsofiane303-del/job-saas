import { motion } from 'framer-motion';
import Card from '../common/Card';
import { fadeInUp } from '../../utils/animations';

const CVComparison = ({ original, optimized, improvements = [] }) => {
  return (
    <motion.div
      className="grid grid-cols-1 lg:grid-cols-2 gap-8"
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      {/* Original CV */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white">CV Original</h3>
          <span className="px-3 py-1 bg-dark-700 text-dark-400 rounded-full text-xs">
            Avant
          </span>
        </div>

        <div className="space-y-4">
          {/* Summary */}
          {original?.summary && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Résumé</p>
              <p className="text-sm text-dark-300 leading-relaxed">
                {original.summary}
              </p>
            </div>
          )}

          {/* Skills */}
          {original?.skills?.technical && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Compétences</p>
              <div className="flex flex-wrap gap-2">
                {original.skills.technical.slice(0, 8).map((skill, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-dark-700 text-dark-300 rounded text-xs"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Experience */}
          {original?.experience && original.experience.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Dernière expérience</p>
              <div className="p-3 bg-dark-900 rounded-lg">
                <p className="text-white font-medium text-sm">
                  {original.experience[0].title}
                </p>
                <p className="text-dark-400 text-xs mt-1">
                  {original.experience[0].company}
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Optimized CV */}
      <Card className="border-primary-500/30">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white">CV Optimisé</h3>
          <span className="px-3 py-1 bg-primary-600 text-white rounded-full text-xs">
            Après
          </span>
        </div>

        <div className="space-y-4">
          {/* Summary */}
          {optimized?.summary && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Résumé amélioré</p>
              <p className="text-sm text-white leading-relaxed">
                {optimized.summary}
              </p>
            </div>
          )}

          {/* Skills */}
          {optimized?.skills?.technical && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Compétences réorganisées</p>
              <div className="flex flex-wrap gap-2">
                {optimized.skills.technical.slice(0, 8).map((skill, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-primary-600/20 text-primary-400 rounded text-xs border border-primary-600/30"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Experience */}
          {optimized?.experience && optimized.experience.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-dark-400 mb-2">Expérience optimisée</p>
              <div className="p-3 bg-primary-600/10 rounded-lg border border-primary-600/30">
                <p className="text-white font-medium text-sm">
                  {optimized.experience[0].title}
                </p>
                <p className="text-primary-400 text-xs mt-1">
                  {optimized.experience[0].company}
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Improvements */}
      {improvements.length > 0 && (
        <div className="lg:col-span-2">
          <Card className="bg-gradient-to-br from-primary-600/10 to-blue-600/10 border-primary-500/30">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <svg className="w-6 h-6 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Améliorations apportées
            </h3>
            <div className="space-y-3">
              {improvements.map((improvement, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-4 bg-dark-900/50 rounded-lg"
                >
                  <div className="flex-shrink-0 w-6 h-6 bg-primary-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="text-white text-sm">{improvement}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </motion.div>
  );
};

export default CVComparison;

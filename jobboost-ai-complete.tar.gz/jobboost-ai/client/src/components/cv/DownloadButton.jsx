import { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../common/Button';
import { cvAPI } from '../../services/api';
import { downloadFile } from '../../utils/helpers';
import toast from 'react-hot-toast';

const DownloadButton = ({ filename, cvUrl }) => {
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    try {
      setDownloading(true);
      
      // Si c'est une URL complète
      if (cvUrl) {
        downloadFile(cvUrl, filename || 'cv_optimized.html');
        toast.success('Téléchargement démarré !');
      } else if (filename) {
        const url = cvAPI.downloadCV(filename);
        downloadFile(url, filename);
        toast.success('Téléchargement démarré !');
      } else {
        toast.error('Fichier non disponible');
      }
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Erreur lors du téléchargement');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        variant="primary"
        size="lg"
        onClick={handleDownload}
        loading={downloading}
        icon={
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
        }
      >
        Télécharger le CV
      </Button>
    </motion.div>
  );
};

export default DownloadButton;

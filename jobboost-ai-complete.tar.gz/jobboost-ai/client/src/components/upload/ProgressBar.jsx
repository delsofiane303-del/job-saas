import { motion } from 'framer-motion';
import { progressBarVariants } from '../../utils/animations';

const ProgressBar = ({ progress = 0, label = '' }) => {
  return (
    <div className="w-full">
      {/* Label */}
      {label && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-white">{label}</span>
          <span className="text-sm font-bold text-primary-500">{progress}%</span>
        </div>
      )}

      {/* Progress Bar Container */}
      <div className="h-3 bg-dark-700 rounded-full overflow-hidden border border-dark-600">
        <motion.div
          className="h-full bg-gradient-blue shadow-glow-sm"
          custom={progress}
          variants={progressBarVariants}
          initial="initial"
          animate="animate"
        />
      </div>

      {/* Status Message */}
      {progress < 100 ? (
        <p className="text-xs text-dark-400 mt-2">
          Upload en cours...
        </p>
      ) : (
        <p className="text-xs text-green-500 mt-2 flex items-center gap-1">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          Upload terminé
        </p>
      )}
    </div>
  );
};

export default ProgressBar;

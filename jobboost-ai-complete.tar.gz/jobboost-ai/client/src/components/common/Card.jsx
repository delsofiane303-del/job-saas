import { motion } from 'framer-motion';
import { fadeInUp } from '../../utils/animations';

const Card = ({
  children,
  className = '',
  hover = true,
  gradient = false,
  glass = false,
  ...props
}) => {
  const baseClasses = 'rounded-xl p-6 transition-all duration-300';
  
  const variantClasses = glass
    ? 'glass'
    : gradient
    ? 'bg-gradient-to-br from-dark-800 to-dark-900 border border-dark-700'
    : 'bg-dark-800 border border-dark-700';

  const hoverClasses = hover ? 'hover:border-primary-500/50 hover:shadow-glow-sm' : '';

  return (
    <motion.div
      className={`${baseClasses} ${variantClasses} ${hoverClasses} ${className}`}
      initial="initial"
      animate="animate"
      variants={fadeInUp}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default Card;

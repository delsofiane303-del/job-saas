import { motion } from 'framer-motion';
import Card from '../common/Card';
import Button from '../common/Button';
import { getScoreColor, getScoreBgColor } from '../../utils/helpers';
import { staggerItem } from '../../utils/animations';

const JobCard = ({ job, onSelectJob }) => {
  const { job_title, compatibility_score, average_salary, required_skills, missing_skills, description } = job;

  return (
    <motion.div variants={staggerItem}>
      <Card className="h-full">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">{job_title}</h3>
            <p className="text-dark-400 text-sm line-clamp-2">{description}</p>
          </div>
          
          {/* Score Badge */}
          <div className="ml-4">
            <div className={`relative w-20 h-20 rounded-full ${getScoreBgColor(compatibility_score)} flex items-center justify-center`}>
              <div className="absolute inset-1 bg-dark-800 rounded-full flex flex-col items-center justify-center">
                <span className={`text-2xl font-bold ${getScoreColor(compatibility_score)}`}>
                  {compatibility_score}
                </span>
                <span className="text-xs text-dark-400">%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Salary */}
        {average_salary && (
          <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-dark-900 rounded-lg">
            <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-white font-medium">{average_salary}</span>
          </div>
        )}

        {/* Required Skills */}
        {required_skills && required_skills.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-semibold text-dark-400 mb-2">Compétences requises:</p>
            <div className="flex flex-wrap gap-2">
              {required_skills.slice(0, 6).map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-primary-600/10 text-primary-400 rounded-full text-xs font-medium border border-primary-600/30"
                >
                  {skill}
                </span>
              ))}
              {required_skills.length > 6 && (
                <span className="px-3 py-1 bg-dark-700 text-dark-400 rounded-full text-xs font-medium">
                  +{required_skills.length - 6}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Missing Skills */}
        {missing_skills && missing_skills.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-semibold text-dark-400 mb-2">À développer:</p>
            <div className="flex flex-wrap gap-2">
              {missing_skills.slice(0, 4).map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-yellow-600/10 text-yellow-400 rounded-full text-xs font-medium border border-yellow-600/30"
                >
                  {skill}
                </span>
              ))}
              {missing_skills.length > 4 && (
                <span className="px-3 py-1 bg-dark-700 text-dark-400 rounded-full text-xs font-medium">
                  +{missing_skills.length - 4}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 mt-6 pt-4 border-t border-dark-700">
          <Button
            variant="primary"
            size="sm"
            className="flex-1"
            onClick={() => onSelectJob(job)}
          >
            Optimiser mon CV
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              // TODO: Voir les détails du métier
            }}
          >
            Détails
          </Button>
        </div>
      </Card>
    </motion.div>
  );
};

export default JobCard;

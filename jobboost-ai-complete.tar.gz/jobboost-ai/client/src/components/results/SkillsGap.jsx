import { motion } from 'framer-motion';
import Card from '../common/Card';
import { fadeInUp } from '../../utils/animations';

const SkillsGap = ({ analysis }) => {
  const { skills } = analysis;

  const allSkills = [
    ...(skills?.technical || []),
    ...(skills?.soft || []),
  ];

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      <Card>
        <h3 className="text-xl font-bold text-white mb-6">Vos compétences</h3>

        {/* Technical Skills */}
        {skills?.technical && skills.technical.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-dark-400 mb-3">Compétences techniques</h4>
            <div className="grid grid-cols-2 gap-3">
              {skills.technical.map((skill, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 p-3 bg-dark-900 rounded-lg border border-dark-700"
                >
                  <div className="w-2 h-2 bg-primary-500 rounded-full" />
                  <span className="text-white text-sm">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Soft Skills */}
        {skills?.soft && skills.soft.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-dark-400 mb-3">Soft skills</h4>
            <div className="grid grid-cols-2 gap-3">
              {skills.soft.map((skill, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 p-3 bg-dark-900 rounded-lg border border-dark-700"
                >
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span className="text-white text-sm">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Languages */}
        {skills?.languages && skills.languages.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold text-dark-400 mb-3">Langues</h4>
            <div className="flex flex-wrap gap-2">
              {skills.languages.map((lang, index) => (
                <span
                  key={index}
                  className="px-4 py-2 bg-green-600/10 text-green-400 rounded-lg text-sm font-medium border border-green-600/30"
                >
                  {lang}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="mt-6 pt-6 border-t border-dark-700">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-gradient mb-1">
                {skills?.technical?.length || 0}
              </div>
              <div className="text-xs text-dark-400">Techniques</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-gradient mb-1">
                {skills?.soft?.length || 0}
              </div>
              <div className="text-xs text-dark-400">Soft skills</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-gradient mb-1">
                {allSkills.length}
              </div>
              <div className="text-xs text-dark-400">Total</div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default SkillsGap;

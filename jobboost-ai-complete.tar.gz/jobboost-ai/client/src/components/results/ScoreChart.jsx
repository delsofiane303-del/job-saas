import { motion } from 'framer-motion';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import Card from '../common/Card';
import { fadeInUp } from '../../utils/animations';

const ScoreChart = ({ recommendations = [] }) => {
  const data = recommendations.map((rec) => ({
    name: rec.job_title,
    value: rec.compatibility_score,
  }));

  const COLORS = ['#3B82F6', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B'];

  return (
    <motion.div
      initial="initial"
      animate="animate"
      variants={fadeInUp}
    >
      <Card>
        <h3 className="text-xl font-bold text-white mb-6">Répartition des scores</h3>
        
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: '#1E293B',
                border: '1px solid #334155',
                borderRadius: '8px',
                color: '#fff',
              }}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              wrapperStyle={{ color: '#94a3b8' }}
            />
          </PieChart>
        </ResponsiveContainer>

        <div className="mt-6 space-y-2">
          {recommendations.map((rec, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-dark-900 rounded-lg">
              <div className="flex items-center gap-3">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                />
                <span className="text-white text-sm font-medium">{rec.job_title}</span>
              </div>
              <span className="text-primary-500 font-bold">{rec.compatibility_score}%</span>
            </div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
};

export default ScoreChart;

import { motion } from 'framer-motion';
import { ANALYSIS_STEPS } from '../../utils/constants';

const StepIndicator = ({ currentStep = 0 }) => {
  const getStepStatus = (stepId) => {
    if (stepId < currentStep) return 'completed';
    if (stepId === currentStep) return 'active';
    return 'pending';
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="relative">
        {/* Progress Line */}
        <div className="absolute top-8 left-0 w-full h-1 bg-dark-700">
          <motion.div
            className="h-full bg-gradient-blue"
            initial={{ width: 0 }}
            animate={{ width: `${(currentStep / ANALYSIS_STEPS.length) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        {/* Steps */}
        <div className="relative grid grid-cols-4 gap-4">
          {ANALYSIS_STEPS.map((step) => {
            const status = getStepStatus(step.id);
            
            return (
              <div key={step.id} className="flex flex-col items-center">
                {/* Step Circle */}
                <motion.div
                  className={`
                    w-16 h-16 rounded-full border-4 flex items-center justify-center mb-3 transition-all
                    ${status === 'completed' 
                      ? 'bg-primary-600 border-primary-600' 
                      : status === 'active'
                      ? 'bg-primary-600 border-primary-600 shadow-glow'
                      : 'bg-dark-800 border-dark-700'
                    }
                  `}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: step.id * 0.1 }}
                >
                  {status === 'completed' ? (
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  ) : status === 'active' ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    >
                      <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    </motion.div>
                  ) : (
                    <span className="text-2xl font-bold text-dark-600">{step.id}</span>
                  )}
                </motion.div>

                {/* Step Info */}
                <div className="text-center">
                  <p className={`
                    text-sm font-semibold mb-1
                    ${status === 'active' ? 'text-white' : status === 'completed' ? 'text-primary-500' : 'text-dark-500'}
                  `}>
                    {step.name}
                  </p>
                  <p className="text-xs text-dark-400">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StepIndicator;

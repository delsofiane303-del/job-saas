import { motion } from 'framer-motion';
import { pulseAnimation, rotateAnimation } from '../../utils/animations';

const AnalysisAnimation = ({ currentStep = 0 }) => {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="relative">
        {/* Outer Ring */}
        <motion.div
          className="absolute inset-0 w-48 h-48 border-4 border-primary-600/20 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />

        {/* Middle Ring */}
        <motion.div
          className="absolute inset-4 w-40 h-40 border-4 border-primary-500/30 rounded-full"
          animate={{ rotate: -360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        />

        {/* Inner Ring */}
        <motion.div
          className="absolute inset-8 w-32 h-32 border-4 border-primary-400/40 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        />

        {/* Center Icon */}
        <motion.div
          className="relative w-48 h-48 bg-gradient-to-br from-primary-600 to-blue-600 rounded-full flex items-center justify-center shadow-glow"
          animate={{
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <svg className="w-20 h-20 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        </motion.div>

        {/* Orbiting Dots */}
        {[0, 1, 2, 3].map((i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 bg-primary-500 rounded-full"
            style={{
              left: '50%',
              top: '50%',
              marginLeft: -8,
              marginTop: -8,
            }}
            animate={{
              rotate: 360,
              x: Math.cos((i * Math.PI) / 2) * 100,
              y: Math.sin((i * Math.PI) / 2) * 100,
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "linear",
              delay: i * 0.2,
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default AnalysisAnimation;

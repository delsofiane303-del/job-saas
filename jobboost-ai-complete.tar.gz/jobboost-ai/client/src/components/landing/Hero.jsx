import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@clerk/clerk-react';
import Button from '../common/Button';
import { fadeInUp, staggerContainer, staggerItem } from '../../utils/animations';

const Hero = () => {
  const navigate = useNavigate();
  const { isSignedIn } = useAuth();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark-900 via-primary-900/10 to-dark-900" />
      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
      
      {/* Animated Circles */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 bg-primary-600/20 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.5, 0.3, 0.5],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Content */}
      <motion.div
        className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
        variants={staggerContainer}
        initial="initial"
        animate="animate"
      >
        <motion.div
          className="inline-block mb-6 px-4 py-2 bg-primary-600/10 border border-primary-600/30 rounded-full"
          variants={staggerItem}
        >
          <span className="text-primary-400 text-sm font-medium">
            🚀 Propulsé par l'IA
          </span>
        </motion.div>

        <motion.h1
          className="text-5xl md:text-7xl font-bold mb-6"
          variants={staggerItem}
        >
          <span className="text-gradient">Boostez votre carrière</span>
          <br />
          <span className="text-white">avec l'intelligence artificielle</span>
        </motion.h1>

        <motion.p
          className="text-xl text-dark-300 max-w-3xl mx-auto mb-8"
          variants={staggerItem}
        >
          Uploadez votre CV, découvrez les métiers parfaitement adaptés à votre profil
          et obtenez une version optimisée de votre CV en quelques minutes.
        </motion.p>

        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          variants={staggerItem}
        >
          <Button
            size="lg"
            onClick={() => navigate(isSignedIn ? '/dashboard' : '/login')}
            className="shadow-glow"
          >
            {isSignedIn ? 'Accéder au Dashboard' : 'Commencer gratuitement'}
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </Button>
          <Button
            variant="secondary"
            size="lg"
            onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Comment ça marche ?
          </Button>
        </motion.div>

        <motion.div
          className="mt-12 flex items-center justify-center gap-8 text-dark-400 text-sm"
          variants={staggerItem}
        >
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>5 crédits gratuits</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>Aucune carte requise</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>Résultats en 2 minutes</span>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          variants={staggerContainer}
        >
          {[
            { value: '10,000+', label: 'CV analysés' },
            { value: '95%', label: 'Satisfaction' },
            { value: '500+', label: 'Métiers référencés' },
          ].map((stat, index) => (
            <motion.div
              key={index}
              className="glass p-6 rounded-xl"
              variants={staggerItem}
            >
              <div className="text-4xl font-bold text-gradient mb-2">{stat.value}</div>
              <div className="text-dark-400">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;

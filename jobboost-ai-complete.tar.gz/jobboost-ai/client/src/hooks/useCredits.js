import { useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';

export const useCredits = () => {
  const [credits, setCredits] = useState(null);
  const [plan, setPlan] = useState('free');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchCredits = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await authAPI.getCredits();
      
      if (response.data.success) {
        setCredits(response.data.credits);
        setPlan(response.data.plan);
        return response.data.credits;
      }
      
      return null;
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Erreur lors de la récupération des crédits';
      setError(errorMessage);
      console.error('Error fetching credits:', err);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const decrementCredits = useCallback(() => {
    setCredits(prev => prev !== null ? Math.max(0, prev - 1) : null);
  }, []);

  const hasCredits = useCallback(() => {
    return credits !== null && credits > 0;
  }, [credits]);

  useEffect(() => {
    fetchCredits();
  }, [fetchCredits]);

  return {
    credits,
    plan,
    loading,
    error,
    fetchCredits,
    decrementCredits,
    hasCredits,
  };
};

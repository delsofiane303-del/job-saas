import { useState, useCallback } from 'react';
import { uploadAPI } from '../services/api';
import { validatePDFFile } from '../services/pdfParser';
import toast from 'react-hot-toast';

export const useUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const [analysisId, setAnalysisId] = useState(null);

  const uploadCV = useCallback(async (file) => {
    try {
      setUploading(true);
      setError(null);
      setProgress(0);

      // Valider le fichier
      const validation = validatePDFFile(file);
      if (!validation.valid) {
        throw new Error(validation.error);
      }

      // Créer le FormData
      const formData = new FormData();
      formData.append('cv', file);

      // Simuler la progression
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Upload
      const response = await uploadAPI.uploadCV(formData);

      clearInterval(progressInterval);
      setProgress(100);

      if (response.data.success) {
        setAnalysisId(response.data.analysis.id);
        toast.success('CV uploadé avec succès !');
        return response.data.analysis;
      }

      throw new Error('Erreur lors de l\'upload');
    } catch (err) {
      const errorMessage = err.response?.data?.error || err.message || 'Erreur lors de l\'upload';
      setError(errorMessage);
      toast.error(errorMessage);
      setProgress(0);
      return null;
    } finally {
      setUploading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setUploading(false);
    setProgress(0);
    setError(null);
    setAnalysisId(null);
  }, []);

  return {
    uploading,
    progress,
    error,
    analysisId,
    uploadCV,
    reset,
  };
};

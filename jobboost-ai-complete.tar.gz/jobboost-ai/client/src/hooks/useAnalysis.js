import { useState, useEffect, useCallback } from 'react';
import { analysisAPI } from '../services/api';
import toast from 'react-hot-toast';

export const useAnalysis = (analysisId) => {
  const [analysis, setAnalysis] = useState(null);
  const [status, setStatus] = useState('pending');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [results, setResults] = useState(null);

  const startAnalysis = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await analysisAPI.startAnalysis(analysisId);
      
      if (response.data.success) {
        toast.success('Analyse démarrée');
        return true;
      }
      
      return false;
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Erreur lors du démarrage de l\'analyse';
      setError(errorMessage);
      toast.error(errorMessage);
      return false;
    } finally {
      setLoading(false);
    }
  }, [analysisId]);

  const checkStatus = useCallback(async () => {
    try {
      const response = await analysisAPI.getAnalysisStatus(analysisId);
      
      if (response.data.success) {
        setStatus(response.data.analysis.status);
        setAnalysis(response.data.analysis);
        return response.data.analysis.status;
      }
      
      return null;
    } catch (err) {
      console.error('Error checking status:', err);
      return null;
    }
  }, [analysisId]);

  const getResults = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await analysisAPI.getAnalysisResults(analysisId);
      
      if (response.data.success) {
        setResults(response.data.analysis);
        return response.data.analysis;
      }
      
      return null;
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Erreur lors de la récupération des résultats';
      setError(errorMessage);
      toast.error(errorMessage);
      return null;
    } finally {
      setLoading(false);
    }
  }, [analysisId]);

  // Polling pour vérifier le statut
  useEffect(() => {
    if (!analysisId) return;

    let interval;
    
    const pollStatus = async () => {
      const currentStatus = await checkStatus();
      
      if (currentStatus === 'completed' || currentStatus === 'failed') {
        clearInterval(interval);
        
        if (currentStatus === 'completed') {
          await getResults();
        }
      }
    };

    // Vérifier immédiatement
    pollStatus();

    // Puis vérifier toutes les 3 secondes
    interval = setInterval(pollStatus, 3000);

    return () => clearInterval(interval);
  }, [analysisId, checkStatus, getResults]);

  return {
    analysis,
    status,
    loading,
    error,
    results,
    startAnalysis,
    checkStatus,
    getResults,
  };
};

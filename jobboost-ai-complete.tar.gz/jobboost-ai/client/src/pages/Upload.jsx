import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import DragDrop from '../components/upload/DragDrop';
import ProgressBar from '../components/upload/ProgressBar';
import { useUpload } from '../hooks/useUpload';
import { useApp } from '../context/AppContext';
import { fadeInUp } from '../utils/animations';
import toast from 'react-hot-toast';

const Upload = () => {
  const navigate = useNavigate();
  const { credits, decrementCredits } = useApp();
  const { uploading, progress, error, analysisId, uploadCV, reset } = useUpload();
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileSelect = (file) => {
    setSelectedFile(file);
    reset();
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error('Veuillez sélectionner un fichier');
      return;
    }

    if (credits === 0) {
      toast.error('Vous n\'avez plus de crédits');
      return;
    }

    const result = await uploadCV(selectedFile);

    if (result) {
      decrementCredits();
      toast.success('Analyse démarrée !');
      
      // Rediriger vers la page d'analyse
      setTimeout(() => {
        navigate(`/analysis/${result.id}`);
      }, 1000);
    }
  };

  const handleCancel = () => {
    setSelectedFile(null);
    reset();
  };

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-white mb-2">Upload de CV</h1>
              <p className="text-dark-400">
                Uploadez votre CV pour commencer l'analyse IA
              </p>
            </div>

            {/* Credits Warning */}
            {credits !== null && credits <= 2 && (
              <Card className="mb-6 bg-yellow-600/10 border-yellow-600/30">
                <div className="flex items-center gap-3">
                  <svg className="w-6 h-6 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="text-yellow-500 font-medium">
                      Attention : il ne vous reste que {credits} crédit{credits > 1 ? 's' : ''}
                    </p>
                    <p className="text-yellow-400/80 text-sm">
                      Pensez à acheter des crédits pour continuer à utiliser JobBoost AI
                    </p>
                  </div>
                </div>
              </Card>
            )}

            {/* Upload Section */}
            <Card>
              <DragDrop
                onFileSelect={handleFileSelect}
                disabled={uploading}
              />

              {/* Progress */}
              {uploading && (
                <div className="mt-6">
                  <ProgressBar progress={progress} label="Upload en cours" />
                </div>
              )}

              {/* File Info */}
              {selectedFile && !uploading && (
                <div className="mt-6 p-4 bg-dark-900 rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary-600/10 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-white font-medium">{selectedFile.name}</p>
                      <p className="text-dark-400 text-sm">
                        {(selectedFile.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleCancel}
                    className="text-red-500 hover:text-red-400 transition-colors"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              )}

              {/* Actions */}
              {selectedFile && !uploading && (
                <div className="mt-6 flex gap-4">
                  <Button
                    variant="primary"
                    size="lg"
                    onClick={handleUpload}
                    className="flex-1"
                    disabled={credits === 0}
                  >
                    Lancer l'analyse (1 crédit)
                  </Button>
                  <Button
                    variant="secondary"
                    size="lg"
                    onClick={handleCancel}
                  >
                    Annuler
                  </Button>
                </div>
              )}

              {error && (
                <div className="mt-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <p className="text-red-500 text-sm">{error}</p>
                </div>
              )}
            </Card>

            {/* Info */}
            <Card className="mt-6 bg-dark-800/50">
              <h3 className="text-lg font-bold text-white mb-4">Conseils pour un meilleur résultat</h3>
              <ul className="space-y-2">
                {[
                  'Utilisez un CV à jour avec vos dernières expériences',
                  'Assurez-vous que le texte est lisible (pas uniquement des images)',
                  'Incluez vos compétences techniques et soft skills',
                  'Mentionnez vos formations et certifications',
                ].map((tip, index) => (
                  <li key={index} className="flex items-start gap-2 text-dark-300">
                    <svg className="w-5 h-5 text-primary-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm">{tip}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Upload;

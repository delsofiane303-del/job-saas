import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import JobCard from '../components/results/JobCard';
import ScoreChart from '../components/results/ScoreChart';
import SkillsGap from '../components/results/SkillsGap';
import { analysisAPI, cvAPI } from '../services/api';
import { fadeInUp, staggerContainer, staggerItem } from '../utils/animations';
import toast from 'react-hot-toast';

const Results = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [analysis, setAnalysis] = useState(null);
  const [generatingCV, setGeneratingCV] = useState(false);

  useEffect(() => {
    fetchResults();
  }, [id]);

  const fetchResults = async () => {
    try {
      setLoading(true);
      const response = await analysisAPI.getAnalysisResults(id);
      
      if (response.data.success) {
        setAnalysis(response.data.analysis);
      }
    } catch (error) {
      console.error('Error fetching results:', error);
      toast.error('Erreur lors du chargement des résultats');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectJob = async (job) => {
    try {
      setGeneratingCV(true);
      toast.loading('Génération du CV optimisé...');
      
      await cvAPI.generateCV(id, job.job_title);
      
      toast.dismiss();
      toast.success('CV généré avec succès !');
      
      // Rediriger vers la page du CV optimisé
      navigate(`/cv/${id}`);
    } catch (error) {
      console.error('Error generating CV:', error);
      toast.dismiss();
      toast.error('Erreur lors de la génération du CV');
    } finally {
      setGeneratingCV(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8 flex items-center justify-center">
          <Loader text="Chargement des résultats..." />
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8">
          <Card className="text-center py-12">
            <p className="text-dark-400">Aucun résultat trouvé</p>
            <Button onClick={() => navigate('/dashboard')} className="mt-4">
              Retour au dashboard
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-white mb-2">
                Résultats de l'analyse
              </h1>
              <p className="text-dark-400">
                Découvrez les métiers adaptés à votre profil
              </p>
            </div>

            {/* Success Message */}
            <Card className="mb-8 bg-gradient-to-br from-green-600/10 to-green-600/5 border-green-500/30">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Analyse terminée !</h3>
                  <p className="text-green-400 text-sm">
                    Nous avons trouvé {analysis.recommendations?.length || 0} métiers correspondant à votre profil
                  </p>
                </div>
              </div>
            </Card>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <SkillsGap analysis={analysis} />
              {analysis.recommendations && analysis.recommendations.length > 0 && (
                <ScoreChart recommendations={analysis.recommendations} />
              )}
            </div>

            {/* Job Recommendations */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">
                Métiers recommandés
              </h2>
              
              {analysis.recommendations && analysis.recommendations.length > 0 ? (
                <motion.div
                  className="grid grid-cols-1 lg:grid-cols-2 gap-6"
                  variants={staggerContainer}
                  initial="initial"
                  animate="animate"
                >
                  {analysis.recommendations
                    .sort((a, b) => b.compatibility_score - a.compatibility_score)
                    .map((job, index) => (
                      <JobCard
                        key={index}
                        job={job}
                        onSelectJob={handleSelectJob}
                      />
                    ))}
                </motion.div>
              ) : (
                <Card className="text-center py-12">
                  <p className="text-dark-400">Aucune recommandation disponible</p>
                </Card>
              )}
            </div>

            {/* Actions */}
            <Card className="bg-gradient-to-br from-primary-600/10 to-blue-600/10 border-primary-500/30">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">
                    Prêt à optimiser votre CV ?
                  </h3>
                  <p className="text-dark-400 text-sm">
                    Sélectionnez un métier ci-dessus pour générer un CV optimisé
                  </p>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => navigate('/dashboard')}
                >
                  Retour au dashboard
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Results;

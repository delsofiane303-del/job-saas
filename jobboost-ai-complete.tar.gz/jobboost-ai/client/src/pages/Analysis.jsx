import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import Card from '../components/common/Card';
import Loader from '../components/common/Loader';
import AnalysisAnimation from '../components/analysis/AnalysisAnimation';
import StepIndicator from '../components/analysis/StepIndicator';
import { useAnalysis } from '../hooks/useAnalysis';
import { fadeInUp } from '../utils/animations';
import { ANALYSIS_STATUS, ANALYSIS_STEPS } from '../utils/constants';

const Analysis = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { status, loading, error, startAnalysis, results } = useAnalysis(id);
  const [currentStep, setCurrentStep] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);

  useEffect(() => {
    const start = async () => {
      if (!hasStarted && id) {
        setHasStarted(true);
        await startAnalysis();
      }
    };
    start();
  }, [id, hasStarted, startAnalysis]);

  useEffect(() => {
    // Mettre à jour l'étape en fonction du statut
    switch (status) {
      case ANALYSIS_STATUS.ANALYZING_SKILLS:
        setCurrentStep(1);
        break;
      case ANALYSIS_STATUS.SKILLS_ANALYZED:
      case ANALYSIS_STATUS.RECOMMENDING_JOBS:
        setCurrentStep(2);
        break;
      case ANALYSIS_STATUS.JOBS_RECOMMENDED:
        setCurrentStep(3);
        break;
      case ANALYSIS_STATUS.COMPLETED:
        setCurrentStep(4);
        // Rediriger vers les résultats après 1 seconde
        setTimeout(() => {
          navigate(`/results/${id}`);
        }, 1000);
        break;
      default:
        setCurrentStep(0);
    }
  }, [status, navigate, id]);

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8">
          <div className="max-w-4xl mx-auto">
            <Card className="text-center py-12">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Erreur d'analyse</h2>
              <p className="text-dark-400 mb-6">{error}</p>
              <button
                onClick={() => navigate('/dashboard')}
                className="btn-primary"
              >
                Retour au dashboard
              </button>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {/* Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-white mb-2">
                Analyse en cours
              </h1>
              <p className="text-dark-400">
                Notre IA analyse votre CV, cela prend généralement 1-2 minutes
              </p>
            </div>

            {/* Animation */}
            <Card className="mb-8">
              <AnalysisAnimation currentStep={currentStep} />
            </Card>

            {/* Step Indicator */}
            <div className="mb-8">
              <StepIndicator currentStep={currentStep} />
            </div>

            {/* Status Messages */}
            <Card className="bg-dark-800/50">
              <div className="space-y-4">
                {ANALYSIS_STEPS.map((step) => {
                  const isCompleted = step.id < currentStep;
                  const isActive = step.id === currentStep;
                  
                  return (
                    <div
                      key={step.id}
                      className={`
                        flex items-center gap-4 p-4 rounded-lg transition-all
                        ${isActive ? 'bg-primary-600/10 border border-primary-600/30' : 'bg-dark-900/50'}
                      `}
                    >
                      {isCompleted ? (
                        <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                          <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      ) : isActive ? (
                        <div className="w-8 h-8">
                          <Loader size="sm" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 bg-dark-700 rounded-full flex items-center justify-center">
                          <span className="text-dark-500 font-bold">{step.id}</span>
                        </div>
                      )}
                      
                      <div className="flex-1">
                        <p className={`font-semibold ${isActive ? 'text-white' : isCompleted ? 'text-primary-500' : 'text-dark-500'}`}>
                          {step.name}
                        </p>
                        <p className="text-dark-400 text-sm">{step.description}</p>
                      </div>

                      {isActive && (
                        <div className="px-3 py-1 bg-primary-600 text-white rounded-full text-xs font-medium">
                          En cours
                        </div>
                      )}
                      {isCompleted && (
                        <div className="px-3 py-1 bg-green-600 text-white rounded-full text-xs font-medium">
                          Terminé
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Fun Facts */}
            <Card className="mt-8 bg-gradient-to-br from-primary-600/10 to-blue-600/10 border-primary-500/30">
              <div className="text-center">
                <h3 className="text-lg font-bold text-white mb-2">Le saviez-vous ?</h3>
                <p className="text-dark-300">
                  Notre IA analyse plus de 500 métiers différents pour trouver ceux qui correspondent le mieux à votre profil unique.
                </p>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Analysis;

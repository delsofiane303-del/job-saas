import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import { historyAPI } from '../services/api';
import { fadeInUp, staggerContainer, staggerItem } from '../utils/animations';
import { formatDateTime } from '../utils/helpers';
import toast from 'react-hot-toast';

const HistoryPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [analyses, setAnalyses] = useState([]);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [analysesResponse, statsResponse] = await Promise.all([
        historyAPI.getAnalysesList(50, 0),
        historyAPI.getStats(),
      ]);

      if (analysesResponse.data.success) {
        setAnalyses(analysesResponse.data.analyses);
      }

      if (statsResponse.data.success) {
        setStats(statsResponse.data.stats);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Erreur lors du chargement de l\'historique');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (analysisId) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette analyse ?')) {
      return;
    }

    try {
      await historyAPI.deleteAnalysis(analysisId);
      toast.success('Analyse supprimée');
      fetchData();
    } catch (error) {
      console.error('Error deleting analysis:', error);
      toast.error('Erreur lors de la suppression');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-green-500 bg-green-500/10';
      case 'processing':
      case 'analyzing_skills':
      case 'recommending_jobs':
        return 'text-yellow-500 bg-yellow-500/10';
      case 'failed':
        return 'text-red-500 bg-red-500/10';
      default:
        return 'text-blue-500 bg-blue-500/10';
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      pending: 'En attente',
      processing: 'En cours',
      text_extracted: 'Texte extrait',
      analyzing_skills: 'Analyse...',
      skills_analyzed: 'Analysé',
      recommending_jobs: 'Recherche...',
      jobs_recommended: 'Terminé',
      completed: 'Terminé',
      failed: 'Échec',
    };
    return labels[status] || status;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8 flex items-center justify-center">
          <Loader text="Chargement de l'historique..." />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-white mb-2">
                Historique
              </h1>
              <p className="text-dark-400">
                Consultez toutes vos analyses passées
              </p>
            </div>

            {/* Stats */}
            {stats && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gradient mb-2">
                      {stats.totalAnalyses}
                    </div>
                    <div className="text-sm text-dark-400">Analyses totales</div>
                  </div>
                </Card>
                <Card>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gradient mb-2">
                      {stats.totalCVs}
                    </div>
                    <div className="text-sm text-dark-400">CV générés</div>
                  </div>
                </Card>
                <Card>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gradient mb-2">
                      {stats.credits}
                    </div>
                    <div className="text-sm text-dark-400">Crédits restants</div>
                  </div>
                </Card>
                <Card>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gradient mb-2">
                      {stats.plan === 'free' ? 'Gratuit' : 'Pro'}
                    </div>
                    <div className="text-sm text-dark-400">Plan actuel</div>
                  </div>
                </Card>
              </div>
            )}

            {/* Analyses List */}
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">
                  Toutes les analyses ({analyses.length})
                </h2>
              </div>

              {analyses.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-dark-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-dark-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <p className="text-dark-400 mb-4">Aucune analyse pour le moment</p>
                  <Button onClick={() => navigate('/upload')}>
                    Commencer une analyse
                  </Button>
                </div>
              ) : (
                <motion.div
                  className="space-y-3"
                  variants={staggerContainer}
                  initial="initial"
                  animate="animate"
                >
                  {analyses.map((analysis) => (
                    <motion.div
                      key={analysis.id}
                      variants={staggerItem}
                      className="flex items-center justify-between p-4 bg-dark-900 rounded-lg border border-dark-700 hover:border-primary-500/50 transition-all"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="w-12 h-12 bg-primary-600/10 rounded-lg flex items-center justify-center">
                          <svg className="w-6 h-6 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>

                        <div className="flex-1 min-w-0">
                          <p className="text-white font-medium truncate">
                            {analysis.original_cv_filename}
                          </p>
                          <p className="text-sm text-dark-400">
                            {formatDateTime(analysis.created_at)}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(analysis.status)}`}>
                          {getStatusLabel(analysis.status)}
                        </span>

                        {analysis.status === 'completed' && (
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => navigate(`/results/${analysis.id}`)}
                          >
                            Voir
                          </Button>
                        )}

                        <button
                          onClick={() => handleDelete(analysis.id)}
                          className="text-red-500 hover:text-red-400 transition-colors p-2"
                        >
                          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default HistoryPage;

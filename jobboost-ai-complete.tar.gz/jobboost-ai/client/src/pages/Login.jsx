import { SignIn } from '@clerk/clerk-react';
import { motion } from 'framer-motion';
import { fadeInUp } from '../utils/animations';

const Login = () => {
  return (
    <div className="min-h-screen bg-gradient-dark flex items-center justify-center p-4">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
      
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 bg-primary-600/20 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className="relative z-10 w-full max-w-md"
        initial="initial"
        animate="animate"
        variants={fadeInUp}
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="w-12 h-12 bg-gradient-blue rounded-lg flex items-center justify-center">
              <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <span className="text-2xl font-bold text-white">JobBoost AI</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Bienvenue</h1>
          <p className="text-dark-400">Connectez-vous pour commencer</p>
        </div>

        {/* Clerk Sign In */}
        <div className="flex justify-center">
          <SignIn
            appearance={{
              elements: {
                rootBox: 'w-full',
                card: 'bg-dark-800 border border-dark-700 shadow-2xl',
                headerTitle: 'text-white',
                headerSubtitle: 'text-dark-400',
                socialButtonsBlockButton: 'bg-dark-700 border-dark-600 text-white hover:bg-dark-600',
                socialButtonsBlockButtonText: 'text-white font-medium',
                formButtonPrimary: 'bg-primary-600 hover:bg-primary-700',
                formFieldInput: 'bg-dark-900 border-dark-600 text-white',
                formFieldLabel: 'text-dark-400',
                footerActionLink: 'text-primary-500 hover:text-primary-400',
                identityPreviewText: 'text-white',
                identityPreviewEditButton: 'text-primary-500',
              },
            }}
            routing="path"
            path="/login"
            signUpUrl="/login"
            afterSignInUrl="/dashboard"
          />
        </div>

        {/* Benefits */}
        <div className="mt-8 glass p-6 rounded-xl">
          <p className="text-sm font-semibold text-white mb-3">En vous inscrivant, vous obtenez :</p>
          <ul className="space-y-2">
            {[
              '5 crédits gratuits',
              'Analyses illimitées de CV',
              'Recommandations personnalisées',
              'CV optimisés par IA',
            ].map((benefit, index) => (
              <li key={index} className="flex items-center gap-2 text-dark-300 text-sm">
                <svg className="w-5 h-5 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                {benefit}
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;

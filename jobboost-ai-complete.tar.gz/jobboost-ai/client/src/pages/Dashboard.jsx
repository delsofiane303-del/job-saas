import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import UserProfile from '../components/dashboard/UserProfile';
import Credits from '../components/dashboard/Credits';
import UploadButton from '../components/dashboard/UploadButton';
import History from '../components/dashboard/History';
import { staggerContainer, staggerItem } from '../utils/animations';

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <motion.div
          className="max-w-7xl mx-auto"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {/* Header */}
          <motion.div className="mb-8" variants={staggerItem}>
            <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-dark-400">Bienvenue sur votre espace personnel</p>
          </motion.div>

          {/* User Profile */}
          <div className="mb-6">
            <UserProfile />
          </div>

          {/* Credits */}
          <div className="mb-6">
            <Credits />
          </div>

          {/* Upload Button */}
          <div className="mb-6">
            <UploadButton />
          </div>

          {/* History */}
          <div>
            <History />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;

import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '../components/layout/Sidebar';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Loader from '../components/common/Loader';
import CVComparison from '../components/cv/CVComparison';
import CVPreview from '../components/cv/CVPreview';
import DownloadButton from '../components/cv/DownloadButton';
import { cvAPI, analysisAPI } from '../services/api';
import { fadeInUp } from '../utils/animations';
import toast from 'react-hot-toast';

const CVOptimized = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [polling, setPolling] = useState(true);
  const [cvData, setCvData] = useState(null);
  const [comparison, setComparison] = useState(null);
  const [viewMode, setViewMode] = useState('comparison'); // 'comparison' or 'preview'

  useEffect(() => {
    checkCVStatus();
  }, [id]);

  useEffect(() => {
    if (!polling) return;

    const interval = setInterval(async () => {
      const status = await checkCVStatus();
      if (status === 'completed') {
        setPolling(false);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [polling, id]);

  const checkCVStatus = async () => {
    try {
      const response = await cvAPI.getCVStatus(id);
      
      if (response.data.status === 'completed') {
        setCvData(response.data.cv);
        await fetchComparison();
        setLoading(false);
        return 'completed';
      } else {
        return 'pending';
      }
    } catch (error) {
      console.error('Error checking CV status:', error);
      setLoading(false);
      return 'error';
    }
  };

  const fetchComparison = async () => {
    try {
      const response = await cvAPI.getComparison(id);
      if (response.data.success) {
        setComparison(response.data.comparison);
      }
    } catch (error) {
      console.error('Error fetching comparison:', error);
    }
  };

  if (loading || polling) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8">
          <div className="max-w-4xl mx-auto">
            <Card className="text-center py-12">
              <Loader text="Génération de votre CV optimisé..." />
              <p className="text-dark-400 mt-4">
                Cela peut prendre quelques instants
              </p>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!cvData) {
    return (
      <div className="min-h-screen bg-gradient-dark pt-16">
        <Sidebar />
        <div className="ml-64 p-8">
          <div className="max-w-4xl mx-auto">
            <Card className="text-center py-12">
              <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">CV non disponible</h2>
              <p className="text-dark-400 mb-6">
                Le CV optimisé n'a pas encore été généré
              </p>
              <Button onClick={() => navigate(`/results/${id}`)}>
                Retour aux résultats
              </Button>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <Sidebar />
      
      <div className="ml-64 p-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            {/* Header */}
            <div className="mb-8 flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  CV Optimisé
                </h1>
                <p className="text-dark-400">
                  Comparez et téléchargez votre CV amélioré
                </p>
              </div>
              <DownloadButton
                filename={cvData.filename}
                cvUrl={cvData.url}
              />
            </div>

            {/* View Toggle */}
            <div className="mb-6 flex gap-2">
              <Button
                variant={viewMode === 'comparison' ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setViewMode('comparison')}
              >
                Comparaison
              </Button>
              <Button
                variant={viewMode === 'preview' ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setViewMode('preview')}
              >
                Aperçu complet
              </Button>
            </div>

            {/* Content */}
            {viewMode === 'comparison' && comparison ? (
              <CVComparison
                original={comparison.original}
                optimized={comparison.optimized}
                improvements={cvData.improvements || []}
              />
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-4">CV Original</h3>
                  {comparison?.original && (
                    <CVPreview cvData={comparison.original} />
                  )}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-4">CV Optimisé</h3>
                  {comparison?.optimized && (
                    <CVPreview cvData={comparison.optimized} isOptimized />
                  )}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="mt-8 flex gap-4">
              <Button
                variant="secondary"
                onClick={() => navigate(`/results/${id}`)}
              >
                Retour aux résultats
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/dashboard')}
              >
                Dashboard
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default CVOptimized;

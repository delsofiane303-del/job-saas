import { createContext, useContext, useState, useEffect } from 'react';
import { useUser } from '@clerk/clerk-react';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const { user, isLoaded, isSignedIn } = useUser();
  const [currentUser, setCurrentUser] = useState(null);
  const [credits, setCredits] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const syncUser = async () => {
      if (!isLoaded) return;
      
      if (isSignedIn && user) {
        try {
          // Synchroniser l'utilisateur avec la base de données
          const syncResponse = await authAPI.syncUser(user.id);
          
          // Récupérer les données utilisateur
          const userResponse = await authAPI.getCurrentUser();
          
          if (userResponse.data.success) {
            setCurrentUser(userResponse.data.user);
            setCredits(userResponse.data.user.credits);
          }
        } catch (error) {
          console.error('Error syncing user:', error);
          toast.error('Erreur lors de la synchronisation');
        }
      } else {
        setCurrentUser(null);
        setCredits(null);
      }
      
      setLoading(false);
    };

    syncUser();
  }, [user, isLoaded, isSignedIn]);

  const refreshCredits = async () => {
    try {
      const response = await authAPI.getCredits();
      if (response.data.success) {
        setCredits(response.data.credits);
      }
    } catch (error) {
      console.error('Error refreshing credits:', error);
    }
  };

  const decrementCredits = () => {
    setCredits(prev => Math.max(0, prev - 1));
  };

  const value = {
    user: currentUser,
    clerkUser: user,
    credits,
    loading,
    isSignedIn,
    refreshCredits,
    decrementCredits,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

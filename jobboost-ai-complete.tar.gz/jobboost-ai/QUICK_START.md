# 🚀 Guide de Démarrage Rapide - JobBoost AI

## 📦 Extraction du Projet

### Option 1 : Utiliser l'archive
```bash
# Extraire l'archive
tar -xzf jobboost-ai-complete.tar.gz
cd jobboost-ai
```

### Option 2 : Créer manuellement
Tous les fichiers sont disponibles dans les documents partagés.

---

## ⚡ Installation Express (5 minutes)

### 1️⃣ Backend
```bash
cd server
npm install
cp .env.example .env
# Éditer .env avec vos clés (voir INSTALLATION.md)
npm run dev
```

✅ Backend prêt sur `http://localhost:5000`

### 2️⃣ Frontend
```bash
cd client
npm install
cp .env.example .env
# Éditer .env avec vos clés
npm run dev
```

✅ Frontend prêt sur `http://localhost:5173`

### 3️⃣ Database
1. Créer un projet sur https://supabase.com
2. Aller dans SQL Editor
3. Copier-coller le contenu de `database/schema.sql`
4. Exécuter

✅ Database prête

---

## 🔑 Clés API Nécessaires

### Clerk (Gratuit)
- Site : https://clerk.com
- Créer une app
- Activer Google + Email auth
- Copier les clés

### Supabase (Gratuit)
- Site : https://supabase.com
- Créer un projet
- Exécuter le SQL
- Copier URL + clés

### OpenAI (Payant)
- Site : https://platform.openai.com
- Créer une clé API
- ⚠️ Définir une limite de dépenses !

---

## 📋 Checklist Rapide

Configuration Backend (.env) :
- [ ] CLERK_SECRET_KEY
- [ ] SUPABASE_URL
- [ ] SUPABASE_SERVICE_KEY
- [ ] OPENAI_API_KEY

Configuration Frontend (.env) :
- [ ] VITE_CLERK_PUBLISHABLE_KEY
- [ ] VITE_SUPABASE_URL
- [ ] VITE_SUPABASE_ANON_KEY

Vérifications :
- [ ] Backend démarre sans erreur
- [ ] Frontend démarre sans erreur
- [ ] Database schema exécuté
- [ ] Inscription fonctionne
- [ ] Upload CV fonctionne

---

## 🎯 Premier Test

1. Ouvrir http://localhost:5173
2. Cliquer "Commencer gratuitement"
3. S'inscrire avec Google
4. Aller dans "Upload CV"
5. Déposer un CV (PDF ou DOCX)
6. Lancer l'analyse
7. Attendre 1-2 minutes
8. Voir les résultats !

---

## 📁 Structure des Fichiers

```
jobboost-ai/
├── client/          78 fichiers React/Vite
├── server/          30 fichiers Node.js
├── database/        1 fichier SQL
└── docs/            Documentation
```

**Total : 109+ fichiers créés !**

---

## 🛠️ Commandes Utiles

### Développement
```bash
# Backend
cd server && npm run dev

# Frontend  
cd client && npm run dev
```

### Production
```bash
# Build frontend
cd client && npm run build

# Start backend
cd server && npm start
```

### Logs
```bash
# Voir les logs backend
cd server && npm run dev

# Voir les logs frontend
# Ouvrir la console du navigateur (F12)
```

---

## 🐛 Dépannage Express

### "Module not found"
```bash
npm install
```

### "Port already in use"
```bash
# Changer le port dans .env
PORT=5001
```

### "Database connection failed"
Vérifier :
- Les clés Supabase dans .env
- Le schema.sql a été exécuté
- Les RLS policies sont actives

### "OpenAI API error"
Vérifier :
- La clé API est valide
- Vous avez des crédits
- Vous utilisez GPT-4 (pas GPT-3.5)

---

## 📚 Documentation Complète

- **README.md** : Vue d'ensemble
- **INSTALLATION.md** : Guide détaillé
- **PROJECT_COMPLETE.md** : Liste de tous les fichiers

---

## 🎨 Personnalisation

### Changer les couleurs
Éditer `client/tailwind.config.js` :
```js
colors: {
  primary: {
    500: '#3B82F6',  // Votre couleur
  }
}
```

### Changer le logo
Remplacer les SVG dans :
- `Navbar.jsx`
- `Footer.jsx`
- `Login.jsx`

### Ajouter une page
1. Créer `client/src/pages/MaPage.jsx`
2. Ajouter la route dans `routes.jsx`
3. Ajouter dans la `Sidebar.jsx`

---

## 🚀 Déploiement

### Backend → Railway
```bash
railway login
railway init
railway up
```

### Frontend → Vercel
```bash
vercel login
vercel
```

### Database → Supabase
Déjà hébergé ! ✅

---

## ✨ Fonctionnalités

✅ Landing page animée  
✅ Auth Google + Email  
✅ Upload drag & drop  
✅ Analyse IA GPT-4  
✅ Recommandations métiers  
✅ Scores de compatibilité  
✅ CV optimisé généré  
✅ Téléchargement PDF/HTML  
✅ Historique complet  
✅ Système de crédits  
✅ Design moderne noir + bleu  
✅ Animations Framer Motion  
✅ Responsive mobile  

---

## 💡 Conseils

1. **Testez d'abord en local** avant de déployer
2. **Définissez une limite OpenAI** pour contrôler les coûts
3. **Sauvegardez vos .env** (ne les commitez pas)
4. **Lisez INSTALLATION.md** pour les détails
5. **Consultez PROJECT_COMPLETE.md** pour la liste complète

---

## 🎉 C'est Parti !

Votre SaaS JobBoost AI est prêt à être lancé.

**Prochaine étape** : Suivre INSTALLATION.md pour configurer les clés API.

Bon développement ! 🚀

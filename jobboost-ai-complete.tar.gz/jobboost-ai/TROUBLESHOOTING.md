# 🔧 Guide de Dépannage - JobBoost AI

## Table des Matières
1. [Erreurs d'Installation](#erreurs-dinstallation)
2. [Erreurs Backend](#erreurs-backend)
3. [Erreurs Frontend](#erreurs-frontend)
4. [Erreurs Database](#erreurs-database)
5. [Erreurs API Externes](#erreurs-api-externes)
6. [Erreurs de Déploiement](#erreurs-de-déploiement)
7. [Problèmes de Performance](#problèmes-de-performance)

---

## Erreurs d'Installation

### ❌ "npm: command not found"

**Cause** : Node.js n'est pas installé

**Solution** :
```bash
# Installer Node.js
# Aller sur https://nodejs.org
# Télécharger la version LTS
# Installer
# Vérifier
node --version
npm --version
```

---

### ❌ "Cannot find module"

**Cause** : Les dépendances ne sont pas installées

**Solution** :
```bash
# Backend
cd server
rm -rf node_modules package-lock.json
npm install

# Frontend
cd client
rm -rf node_modules package-lock.json
npm install
```

---

### ❌ "EACCES: permission denied"

**Cause** : Permissions insuffisantes

**Solution** :
```bash
# Sur Mac/Linux
sudo chown -R $USER ~/.npm
sudo chown -R $USER /usr/local/lib/node_modules

# Ou installer avec --unsafe-perm
npm install --unsafe-perm
```

---

## Erreurs Backend

### ❌ "Port 5000 already in use"

**Cause** : Un autre processus utilise le port 5000

**Solution 1** : Changer le port
```bash
# Dans server/.env
PORT=5001
```

**Solution 2** : Tuer le processus
```bash
# Trouver le processus
lsof -i :5000
# Tuer le processus
kill -9 <PID>
```

---

### ❌ "Missing Clerk Publishable Key"

**Cause** : La clé Clerk n'est pas dans .env

**Solution** :
```bash
# Vérifier server/.env
CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
CLERK_SECRET_KEY=sk_test_xxxxx

# Redémarrer le serveur
npm run dev
```

---

### ❌ "Database connection failed"

**Cause** : Mauvaise configuration Supabase

**Solution** :
```bash
# Vérifier server/.env
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_KEY=eyJhbGci...

# Tester la connexion
curl https://xxxxx.supabase.co/rest/v1/
```

**Checklist** :
- [ ] L'URL Supabase est correcte
- [ ] Les clés sont complètes (très longues)
- [ ] Le schéma SQL a été exécuté
- [ ] Les tables existent dans Supabase

---

### ❌ "OpenAI API error"

**Cause** : Problème avec la clé OpenAI

**Solution** :
```bash
# Vérifier server/.env
OPENAI_API_KEY=sk-xxxxx

# Tester la clé
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"
```

**Problèmes courants** :
- Clé invalide → Créer une nouvelle clé
- Pas de crédits → Ajouter des crédits sur OpenAI
- Rate limit → Attendre ou augmenter la limite
- Mauvais modèle → Vérifier que vous utilisez GPT-4

---

### ❌ "CORS error"

**Cause** : Frontend URL non autorisée

**Solution** :
```bash
# Vérifier server/.env
FRONTEND_URL=http://localhost:5173

# Ou en production
FRONTEND_URL=https://votre-domaine.com

# Redémarrer le serveur
```

---

### ❌ "Multer error: File too large"

**Cause** : Fichier > 10 MB

**Solution** :
```bash
# Augmenter la limite dans server/.env
MAX_FILE_SIZE=20485760

# Ou dans server/src/controllers/uploadController.js
limits: {
  fileSize: 20 * 1024 * 1024 // 20 MB
}
```

---

## Erreurs Frontend

### ❌ "Vite: Failed to resolve import"

**Cause** : Mauvais chemin d'import

**Solution** :
```javascript
// ❌ Mauvais
import Button from 'components/Button'

// ✅ Correct
import Button from '../components/common/Button'
```

---

### ❌ "Clerk: Missing publishable key"

**Cause** : Clé Clerk absente dans .env

**Solution** :
```bash
# Vérifier client/.env
VITE_CLERK_PUBLISHABLE_KEY=pk_test_xxxxx

# IMPORTANT: Le préfixe VITE_ est obligatoire !

# Redémarrer Vite
npm run dev
```

---

### ❌ "Network request failed"

**Cause** : Backend non accessible

**Solution** :
```bash
# Vérifier client/.env
VITE_API_URL=http://localhost:5000/api

# Vérifier que le backend tourne
curl http://localhost:5000/health

# Vérifier les CORS
# Dans server/src/server.js
cors({
  origin: 'http://localhost:5173'
})
```

---

### ❌ "Cannot read property of undefined"

**Cause** : Données non chargées

**Solution** :
```javascript
// ❌ Mauvais
const name = user.name;

// ✅ Correct
const name = user?.name;

// Ou avec vérification
if (user && user.name) {
  const name = user.name;
}
```

---

### ❌ "Hydration failed"

**Cause** : Différence entre SSR et client

**Solution** :
```javascript
// Utiliser useEffect pour le code client-only
useEffect(() => {
  // Code qui s'exécute uniquement côté client
}, []);
```

---

## Erreurs Database

### ❌ "Row Level Security policy violation"

**Cause** : RLS bloque l'accès

**Solution** :
```sql
-- Vérifier les policies dans Supabase
-- Aller dans Authentication > Policies
-- S'assurer que les policies permettent l'accès

-- Exemple de policy
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (clerk_id = auth.jwt() ->> 'sub');
```

---

### ❌ "relation does not exist"

**Cause** : Table non créée

**Solution** :
```sql
-- Réexécuter le schéma complet
-- Dans Supabase SQL Editor
-- Copier database/schema.sql
-- Exécuter

-- Vérifier les tables
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public';
```

---

### ❌ "duplicate key value violates unique constraint"

**Cause** : Tentative d'insertion d'une clé déjà existante

**Solution** :
```javascript
// Utiliser upsert au lieu d'insert
const { data, error } = await supabase
  .from('users')
  .upsert({ clerk_id: userId, ...data }, {
    onConflict: 'clerk_id'
  });
```

---

## Erreurs API Externes

### ❌ "Clerk: Invalid session"

**Cause** : Session expirée

**Solution** :
```javascript
// Se déconnecter et reconnecter
// Ou rafraîchir le token

// Dans le code
const token = await clerk.session.getToken();
```

---

### ❌ "Supabase: JWT expired"

**Cause** : Token Supabase expiré

**Solution** :
```javascript
// Vérifier la clé utilisée
// Utiliser SUPABASE_SERVICE_KEY côté serveur
// Utiliser SUPABASE_ANON_KEY côté client
```

---

### ❌ "OpenAI: Rate limit exceeded"

**Cause** : Trop de requêtes

**Solution** :
```javascript
// Ajouter un retry avec backoff
const retry = async (fn, maxAttempts = 3) => {
  for (let i = 0; i < maxAttempts; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxAttempts - 1) throw error;
      await sleep(1000 * (i + 1));
    }
  }
};
```

---

### ❌ "OpenAI: Insufficient quota"

**Cause** : Pas de crédits OpenAI

**Solution** :
1. Aller sur https://platform.openai.com/account/billing
2. Ajouter une carte de crédit
3. Ajouter des crédits
4. Définir une limite de dépenses

---

## Erreurs de Déploiement

### ❌ "Build failed on Vercel"

**Cause** : Erreurs de build

**Solution** :
```bash
# Tester le build localement
cd client
npm run build

# Si erreurs, les corriger
# Puis redéployer
vercel --prod
```

---

### ❌ "Environment variables not found"

**Cause** : Variables .env non configurées

**Solution** :
```bash
# Sur Vercel
# Aller dans Settings > Environment Variables
# Ajouter toutes les variables avec le préfixe VITE_

# Sur Railway
# Aller dans Variables
# Ajouter toutes les variables sans préfixe
```

---

### ❌ "502 Bad Gateway"

**Cause** : Backend down ou inaccessible

**Solution** :
```bash
# Vérifier les logs Railway
railway logs

# Vérifier que le backend démarre
# Vérifier le PORT dans .env
# Vérifier que le serveur écoute bien sur 0.0.0.0
```

---

### ❌ "CORS error in production"

**Cause** : FRONTEND_URL incorrect

**Solution** :
```bash
# Dans Railway, configurer
FRONTEND_URL=https://votre-domaine.vercel.app

# Vérifier dans server/src/server.js
cors({
  origin: process.env.FRONTEND_URL
})
```

---

## Problèmes de Performance

### 🐌 "L'analyse est très lente"

**Cause** : Appels API séquentiels

**Solution** :
```javascript
// ❌ Mauvais (séquentiel)
const skills = await analyzeSkills();
const jobs = await recommendJobs();

// ✅ Bon (parallèle)
const [skills, jobs] = await Promise.all([
  analyzeSkills(),
  recommendJobs()
]);
```

---

### 🐌 "Le chargement est lent"

**Cause** : Trop de données chargées

**Solution** :
```javascript
// Implémenter la pagination
const { data } = await supabase
  .from('analyses')
  .select('*')
  .range(0, 9)  // Seulement 10 résultats
  .order('created_at', { ascending: false });

// Lazy loading des composants
const Results = lazy(() => import('./pages/Results'));
```

---

### 🐌 "Les animations sont saccadées"

**Cause** : Trop d'animations simultanées

**Solution** :
```javascript
// Réduire la complexité des animations
// Utiliser will-change CSS
.animated-element {
  will-change: transform;
}

// Désactiver les animations sur mobile
const shouldAnimate = window.innerWidth > 768;
```

---

## Commandes de Debug Utiles

### Backend
```bash
# Voir tous les processus Node
ps aux | grep node

# Voir ce qui utilise le port 5000
lsof -i :5000

# Tester l'API
curl http://localhost:5000/health
curl http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer TOKEN"

# Voir les logs en temps réel
tail -f server/logs/app.log
```

### Frontend
```bash
# Build et voir les erreurs
npm run build

# Analyser le bundle
npm run build -- --report

# Nettoyer le cache
rm -rf node_modules/.vite
rm -rf dist
```

### Database
```sql
-- Voir toutes les tables
SELECT * FROM information_schema.tables 
WHERE table_schema = 'public';

-- Voir les policies RLS
SELECT * FROM pg_policies;

-- Compter les enregistrements
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM analyses;
```

---

## Outils de Debug Recommandés

### Backend
- **Postman** : Tester les API
- **Railway CLI** : Voir les logs
- **pgAdmin** : Explorer Supabase

### Frontend
- **React DevTools** : Debug React
- **Redux DevTools** : Debug state
- **Network Tab** : Voir les requêtes

---

## Contact Support

Si le problème persiste :

1. **Vérifier les logs** :
   - Backend : `railway logs` ou console
   - Frontend : Console navigateur (F12)
   - Database : Supabase dashboard

2. **Chercher l'erreur** :
   - Google l'erreur exacte
   - StackOverflow
   - Documentation officielle

3. **Demander de l'aide** :
   - Clerk support
   - Supabase community
   - OpenAI forum

---

## Checklist de Debug

Avant de demander de l'aide :
- [ ] J'ai vérifié les logs
- [ ] J'ai vérifié les variables .env
- [ ] J'ai redémarré le serveur
- [ ] J'ai vidé le cache
- [ ] J'ai testé en navigation privée
- [ ] J'ai vérifié la connexion internet
- [ ] J'ai lu la documentation
- [ ] J'ai cherché l'erreur sur Google

---

**Bon débogage ! 🔧**

*La plupart des erreurs viennent de variables .env mal configurées*

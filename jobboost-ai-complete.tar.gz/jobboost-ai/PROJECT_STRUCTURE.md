# JobBoost AI - Architecture Complète

## Structure du Projet

```
jobboost-ai/
├── client/                    # Frontend React + Vite
├── server/                    # Backend Node.js + Express
├── database/                  # Schémas SQL Supabase
└── shared/                    # Types et utils partagés
```

## Technologies

**Frontend:**
- React 18
- Vite
- Tailwind CSS
- Framer Motion
- Clerk Auth
- React Router
- PDF.js

**Backend:**
- Node.js
- Express
- Supabase Client
- OpenAI API
- Multer (upload)
- pdf-parse

**Database:**
- Supabase (PostgreSQL)

## Démarrage

1. Backend: `cd server && npm install && npm run dev`
2. Frontend: `cd client && npm install && npm run dev`

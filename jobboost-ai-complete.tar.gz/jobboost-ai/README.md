# JobBoost AI - SaaS d'Optimisation de CV avec IA

Application complète de type SaaS permettant d'analyser un CV avec l'IA, de recommander des métiers adaptés et de générer une version optimisée du CV.

## 🚀 Technologies

### Frontend
- **React 18** avec Vite
- **Tailwind CSS** pour le styling
- **Framer Motion** pour les animations
- **Clerk** pour l'authentification
- **React Router** pour la navigation
- **PDF.js** pour la lecture de PDF
- **Axios** pour les appels API

### Backend
- **Node.js** avec Express
- **Supabase** (PostgreSQL) pour la base de données
- **OpenAI API** pour l'analyse IA
- **Multer** pour l'upload de fichiers
- **pdf-parse** pour l'extraction de texte

## 📁 Structure du Projet

```
jobboost-ai/
├── client/          # Frontend React
├── server/          # Backend Node.js
└── database/        # Schémas SQL
```

## 🛠️ Installation

### Prérequis
- Node.js 18+
- npm ou yarn
- Compte Clerk
- Compte Supabase
- Clé API OpenAI

### 1. Cloner le projet
```bash
cd jobboost-ai
```

### 2. Configuration Backend

```bash
cd server
npm install
```

Créer un fichier `.env` à partir de `.env.example`:
```bash
cp .env.example .env
```

Remplir les variables d'environnement:
```env
PORT=5000
NODE_ENV=development

# Clerk
CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
CLERK_SECRET_KEY=sk_test_xxxxx

# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=xxxxx
SUPABASE_SERVICE_KEY=xxxxx

# OpenAI
OPENAI_API_KEY=sk-xxxxx

# Frontend URL
FRONTEND_URL=http://localhost:5173
```

### 3. Configuration Frontend

```bash
cd ../client
npm install
```

Créer un fichier `.env` à partir de `.env.example`:
```bash
cp .env.example .env
```

Remplir les variables d'environnement:
```env
VITE_API_URL=http://localhost:5000/api
VITE_CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=xxxxx
```

### 4. Configuration Base de Données

1. Aller sur [Supabase](https://supabase.com) et créer un nouveau projet
2. Aller dans l'éditeur SQL
3. Copier et exécuter le contenu de `database/schema.sql`

### 5. Configuration Clerk

1. Aller sur [Clerk](https://clerk.com) et créer une application
2. Activer les providers:
   - Google OAuth
   - Email + Password
3. Copier les clés API dans les fichiers `.env`

## 🚦 Démarrage

### Terminal 1 - Backend
```bash
cd server
npm run dev
```
Le serveur démarre sur `http://localhost:5000`

### Terminal 2 - Frontend
```bash
cd client
npm run dev
```
L'application démarre sur `http://localhost:5173`

## 📝 Fonctionnalités

### Landing Page
- Hero avec animations
- Section "Comment ça marche"
- Témoignages
- FAQ
- CTA

### Authentification
- Connexion via Google
- Connexion via Email
- Gérée par Clerk

### Dashboard
- Profil utilisateur
- Affichage des crédits IA
- Bouton d'upload
- Historique des analyses

### Upload de CV
- Drag & Drop
- Support PDF et DOCX
- Barre de progression
- Validation du fichier

### Analyse IA
- Animation pendant l'analyse
- Indicateur d'étapes:
  1. Analyse des compétences
  2. Recherche de métiers
  3. Calcul de compatibilité
  4. Génération du CV

### Résultats
- Liste de métiers recommandés
- Score de compatibilité (%)
- Salaire moyen
- Compétences manquantes
- Bouton pour générer le CV optimisé

### CV Optimisé
- Comparaison côte à côte
- CV original vs CV généré
- Liste des améliorations
- Téléchargement en PDF/HTML

### Historique
- Liste de toutes les analyses
- Statut de chaque analyse
- Accès rapide aux résultats

## 🎨 Design

### Couleurs
- Primaire: Bleu (#3B82F6)
- Secondaire: Bleu foncé
- Background: Noir (#0F172A)
- Accents: Dégradés bleus

### Animations
- Framer Motion pour toutes les animations
- Transitions fluides
- Effets de hover
- Micro-interactions

## 📱 Responsive
- Mobile First
- Breakpoints Tailwind
- Navigation adaptative
- Layout flexible

## 🔐 Sécurité
- Authentification avec Clerk
- JWT pour les sessions
- Row Level Security (RLS) sur Supabase
- Rate limiting sur les API
- Validation des fichiers
- Taille maximale: 10 MB

## 🗄️ Base de Données

### Tables
- `users` - Utilisateurs synchronisés avec Clerk
- `analyses` - Analyses de CV
- `job_recommendations` - Recommandations de métiers
- `generated_cvs` - CV générés
- `history` - Historique des actions

## 🤖 API OpenAI

### Modèle utilisé
- GPT-4

### Prompts
1. **Analyse de CV**: Extraction des compétences, expériences, formations
2. **Recommandations**: Suggestion de métiers adaptés avec scores
3. **Optimisation**: Amélioration du CV pour le métier cible

## 📊 Crédits
- 5 crédits gratuits à l'inscription
- 1 crédit = 1 analyse complète
- Possibilité d'acheter des crédits (à implémenter)

## 🔄 Workflow Complet

1. **Utilisateur** s'inscrit via Clerk
2. **Synchronisation** avec Supabase
3. **Upload** du CV (PDF/DOCX)
4. **Extraction** du texte
5. **Analyse IA** avec OpenAI:
   - Extraction des compétences
   - Analyse de l'expérience
   - Identification des formations
6. **Recommandations**:
   - Recherche de métiers adaptés
   - Calcul de scores de compatibilité
   - Identification des compétences manquantes
7. **Génération CV optimisé**:
   - Restructuration du CV
   - Optimisation pour le métier cible
   - Mise en forme HTML
8. **Téléchargement** du résultat

## 🐛 Débogage

### Backend
```bash
cd server
npm run dev
```
Les logs s'affichent dans le terminal

### Frontend
Ouvrir les DevTools du navigateur (F12)

## 🚀 Déploiement

### Backend
- Déployer sur Railway, Render, ou Heroku
- Configurer les variables d'environnement
- Activer CORS pour le domaine frontend

### Frontend
- Déployer sur Vercel ou Netlify
- Configurer les variables d'environnement
- Pointer vers l'URL du backend

### Base de Données
- Supabase est déjà hébergé
- Pas de configuration supplémentaire nécessaire

## 📄 Licence
MIT

## 👨‍💻 Auteur
JobBoost AI Team

## 🆘 Support
support@jobboost.ai

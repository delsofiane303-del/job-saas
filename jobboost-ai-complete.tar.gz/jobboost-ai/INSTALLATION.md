# Guide d'Installation - JobBoost AI

## Prérequis

- **Node.js** 18 ou supérieur
- **npm** ou **yarn**
- Compte **Clerk** (gratuit)
- Compte **Supabase** (gratuit)
- Clé API **OpenAI** (payant)

---

## Étape 1 : Configuration de Supabase

### 1.1 Créer un projet Supabase

1. Aller sur [https://supabase.com](https://supabase.com)
2. Créer un compte (gratuit)
3. Cliquer sur "New Project"
4. Remplir les informations :
   - **Nom du projet** : jobboost-ai
   - **Mot de passe de la base de données** : (notez-le bien)
   - **Région** : choisir la plus proche de vous

### 1.2 Créer le schéma de la base de données

1. Une fois le projet créé, aller dans **SQL Editor**
2. Créer une nouvelle requête
3. Copier tout le contenu de `database/schema.sql`
4. Coller et exécuter la requête
5. Vérifier que toutes les tables sont créées dans **Table Editor**

### 1.3 Récupérer les clés API

1. Aller dans **Settings** > **API**
2. Copier :
   - **URL** (SUPABASE_URL)
   - **anon public** (SUPABASE_ANON_KEY)
   - **service_role** (SUPABASE_SERVICE_KEY) ⚠️ À garder secret

---

## Étape 2 : Configuration de Clerk

### 2.1 Créer une application Clerk

1. Aller sur [https://clerk.com](https://clerk.com)
2. Créer un compte (gratuit)
3. Cliquer sur "Create Application"
4. Nom de l'application : **JobBoost AI**

### 2.2 Configurer les providers d'authentification

1. Dans le dashboard Clerk, aller dans **User & Authentication** > **Email, Phone, Username**
2. Activer :
   - ✅ **Email address**
   - ✅ **Password**

3. Aller dans **User & Authentication** > **Social Connections**
4. Activer :
   - ✅ **Google**

### 2.3 Récupérer les clés API

1. Aller dans **API Keys**
2. Copier :
   - **Publishable key** (CLERK_PUBLISHABLE_KEY)
   - **Secret key** (CLERK_SECRET_KEY)

---

## Étape 3 : Configuration OpenAI

### 3.1 Obtenir une clé API

1. Aller sur [https://platform.openai.com](https://platform.openai.com)
2. Créer un compte (nécessite une carte bancaire)
3. Aller dans **API Keys**
4. Créer une nouvelle clé : "Create new secret key"
5. Copier la clé (OPENAI_API_KEY)
6. ⚠️ **Important** : Définir une limite de dépenses dans **Billing** > **Usage limits**

---

## Étape 4 : Installation du Backend

### 4.1 Installer les dépendances

```bash
cd server
npm install
```

### 4.2 Configurer les variables d'environnement

1. Créer le fichier `.env` :
```bash
cp .env.example .env
```

2. Éditer `.env` avec vos clés :
```env
# Server
PORT=5000
NODE_ENV=development

# Clerk
CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
CLERK_SECRET_KEY=sk_test_xxxxx

# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# OpenAI
OPENAI_API_KEY=sk-xxxxx

# Frontend
FRONTEND_URL=http://localhost:5173
```

### 4.3 Démarrer le serveur

```bash
npm run dev
```

Le serveur démarre sur `http://localhost:5000`

Vérifier que tout fonctionne :
```bash
curl http://localhost:5000/health
```

Réponse attendue : `{"status":"OK","timestamp":"..."}`

---

## Étape 5 : Installation du Frontend

### 5.1 Installer les dépendances

```bash
cd client
npm install
```

### 5.2 Configurer les variables d'environnement

1. Créer le fichier `.env` :
```bash
cp .env.example .env
```

2. Éditer `.env` avec vos clés :
```env
# API
VITE_API_URL=http://localhost:5000/api

# Clerk
VITE_CLERK_PUBLISHABLE_KEY=pk_test_xxxxx

# Supabase
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 5.3 Démarrer l'application

```bash
npm run dev
```

L'application démarre sur `http://localhost:5173`

---

## Étape 6 : Premier Test

### 6.1 Créer un compte

1. Ouvrir `http://localhost:5173`
2. Cliquer sur "Commencer gratuitement"
3. S'inscrire avec Google ou Email
4. Vérifier que vous êtes redirigé vers le Dashboard

### 6.2 Tester l'upload de CV

1. Préparer un CV au format PDF ou DOCX
2. Aller dans "Upload CV"
3. Glisser-déposer le CV
4. Lancer l'analyse
5. Attendre les résultats (1-2 minutes)

---

## Problèmes Courants

### Erreur : "Missing Clerk Publishable Key"

**Solution** : Vérifier que la clé Clerk est bien dans le fichier `.env` du client avec le préfixe `VITE_`

### Erreur : "401 Unauthorized" lors de l'API

**Solution** : 
- Vérifier que le backend utilise la bonne clé `CLERK_SECRET_KEY`
- Vérifier que Clerk est bien configuré

### Erreur : "OpenAI API error"

**Solution** :
- Vérifier que la clé OpenAI est valide
- Vérifier que vous avez des crédits OpenAI
- Vérifier que vous utilisez bien GPT-4 (pas GPT-3.5)

### Erreur : "Database connection failed"

**Solution** :
- Vérifier les URL et clés Supabase
- Vérifier que le schéma SQL a bien été exécuté
- Vérifier les RLS policies dans Supabase

### Le CV ne s'upload pas

**Solution** :
- Vérifier que le fichier fait moins de 10 MB
- Vérifier que c'est bien un PDF ou DOCX
- Vérifier les logs du serveur

---

## Commandes Utiles

### Backend
```bash
# Installer les dépendances
npm install

# Démarrer en développement
npm run dev

# Démarrer en production
npm start
```

### Frontend
```bash
# Installer les dépendances
npm install

# Démarrer en développement
npm run dev

# Build pour production
npm run build

# Prévisualiser le build
npm run preview
```

---

## Vérifications Finales

✅ Backend démarre sans erreur sur port 5000  
✅ Frontend démarre sans erreur sur port 5173  
✅ L'inscription fonctionne  
✅ Le dashboard s'affiche  
✅ L'upload de CV fonctionne  
✅ L'analyse IA se lance  
✅ Les résultats s'affichent  
✅ Le CV optimisé se génère  

---

## Support

En cas de problème :
1. Vérifier les logs du backend (`server` terminal)
2. Vérifier la console du navigateur (F12)
3. Vérifier que toutes les variables d'environnement sont correctes
4. Consulter le README.md principal

---

## Prochaines Étapes

Une fois l'installation terminée :
1. Personnaliser les couleurs et le design
2. Ajouter votre logo
3. Configurer le paiement pour les crédits
4. Déployer en production (Vercel + Railway)
5. Configurer un nom de domaine

Bon développement ! 🚀

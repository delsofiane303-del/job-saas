import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { extractTextFromFile, validateCV } from '../services/pdfService.js';
import { createAnalysis, addHistoryEntry, getUserByClerkId } from '../services/supabaseService.js';
import fs from 'fs/promises';

// Configuration Multer pour l'upload
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = '/tmp/uploads';
    await fs.mkdir(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Type de fichier non supporté. Utilisez PDF ou DOCX.'), false);
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 // 10 MB
  }
});

export const uploadCV = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Aucun fichier fourni' });
    }

    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Vérifier les crédits
    if (user.credits <= 0) {
      await fs.unlink(req.file.path); // Supprimer le fichier
      return res.status(403).json({ 
        error: 'Crédits insuffisants',
        credits: user.credits
      });
    }

    // Extraire le texte du CV
    const extractedData = await extractTextFromFile(req.file.path, req.file.mimetype);
    
    // Valider que c'est bien un CV
    const validation = validateCV(extractedData.text);
    
    if (!validation.valid) {
      await fs.unlink(req.file.path);
      return res.status(400).json({ error: validation.error });
    }

    // Créer l'analyse dans la base de données
    const analysis = await createAnalysis(user.id, {
      url: req.file.path,
      filename: req.file.originalname
    });

    // Mettre à jour l'analyse avec le texte extrait
    await supabase
      .from('analyses')
      .update({
        extracted_text: extractedData.text,
        status: 'text_extracted'
      })
      .eq('id', analysis.id);

    // Ajouter une entrée dans l'historique
    await addHistoryEntry(user.id, analysis.id, 'upload', {
      filename: req.file.originalname,
      filesize: req.file.size,
      pages: extractedData.pages
    });

    res.json({
      success: true,
      analysis: {
        id: analysis.id,
        filename: req.file.originalname,
        status: 'text_extracted',
        pages: extractedData.pages
      }
    });
  } catch (error) {
    // Nettoyer le fichier en cas d'erreur
    if (req.file) {
      await fs.unlink(req.file.path).catch(console.error);
    }
    next(error);
  }
};

export const getUploadStatus = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    const { data: analysis, error } = await supabase
      .from('analyses')
      .select('id, status, original_cv_filename, created_at')
      .eq('id', analysisId)
      .single();

    if (error) {
      return res.status(404).json({ error: 'Analyse non trouvée' });
    }

    res.json({
      success: true,
      analysis
    });
  } catch (error) {
    next(error);
  }
};

import { analyzeCV, recommendJobs } from '../services/openaiService.js';
import { 
  getAnalysis, 
  updateAnalysis, 
  createJobRecommendations,
  decrementUserCredits,
  getUserByClerkId,
  addHistoryEntry
} from '../services/supabaseService.js';

export const startAnalysis = async (req, res, next) => {
  try {
    const { analysisId } = req.body;
    
    if (!analysisId) {
      return res.status(400).json({ error: 'analysisId requis' });
    }

    // Récupérer l'analyse
    const analysis = await getAnalysis(analysisId);
    
    if (!analysis) {
      return res.status(404).json({ error: 'Analyse non trouvée' });
    }

    if (!analysis.extracted_text) {
      return res.status(400).json({ error: 'Texte du CV non extrait' });
    }

    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Vérifier les crédits
    if (user.credits <= 0) {
      return res.status(403).json({ 
        error: 'Crédits insuffisants',
        credits: user.credits
      });
    }

    // Démarrer l'analyse (réponse immédiate)
    res.json({
      success: true,
      message: 'Analyse démarrée',
      analysisId: analysis.id
    });

    // Processus d'analyse asynchrone
    (async () => {
      try {
        // Étape 1: Analyser les compétences
        await updateAnalysis(analysis.id, { status: 'analyzing_skills' });
        
        const cvAnalysis = await analyzeCV(analysis.extracted_text);
        
        await updateAnalysis(analysis.id, {
          skills: cvAnalysis.skills,
          experience: cvAnalysis.experience,
          education: cvAnalysis.education,
          status: 'skills_analyzed'
        });

        // Étape 2: Recommander des métiers
        await updateAnalysis(analysis.id, { status: 'recommending_jobs' });
        
        const recommendations = await recommendJobs(cvAnalysis);
        
        // Sauvegarder les recommandations
        await createJobRecommendations(analysis.id, recommendations.recommendations);
        
        await updateAnalysis(analysis.id, { status: 'jobs_recommended' });

        // Étape 3: Décrémenter les crédits
        await decrementUserCredits(user.id);

        // Étape 4: Marquer comme complété
        await updateAnalysis(analysis.id, {
          status: 'completed',
          completed_at: new Date().toISOString()
        });

        // Ajouter dans l'historique
        await addHistoryEntry(user.id, analysis.id, 'analysis', {
          recommendationsCount: recommendations.recommendations.length
        });

      } catch (error) {
        console.error('Error in async analysis:', error);
        await updateAnalysis(analysis.id, {
          status: 'failed'
        });
      }
    })();

  } catch (error) {
    next(error);
  }
};

export const getAnalysisStatus = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    const analysis = await getAnalysis(analysisId);
    
    if (!analysis) {
      return res.status(404).json({ error: 'Analyse non trouvée' });
    }

    res.json({
      success: true,
      analysis: {
        id: analysis.id,
        status: analysis.status,
        created_at: analysis.created_at,
        completed_at: analysis.completed_at
      }
    });
  } catch (error) {
    next(error);
  }
};

export const getAnalysisResults = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    const analysis = await getAnalysis(analysisId);
    
    if (!analysis) {
      return res.status(404).json({ error: 'Analyse non trouvée' });
    }

    if (analysis.status !== 'completed') {
      return res.status(400).json({ 
        error: 'Analyse non terminée',
        status: analysis.status
      });
    }

    // Récupérer les recommandations de métiers
    const { data: recommendations, error } = await supabase
      .from('job_recommendations')
      .select('*')
      .eq('analysis_id', analysisId)
      .order('compatibility_score', { ascending: false });

    if (error) throw error;

    res.json({
      success: true,
      analysis: {
        id: analysis.id,
        skills: analysis.skills,
        experience: analysis.experience,
        education: analysis.education,
        recommendations: recommendations || []
      }
    });
  } catch (error) {
    next(error);
  }
};

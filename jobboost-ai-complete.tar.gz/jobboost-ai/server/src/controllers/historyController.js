import { getUserHistory, getUserByClerkId, getUserAnalyses } from '../services/supabaseService.js';

export const getHistory = async (req, res, next) => {
  try {
    const { limit = 50 } = req.query;
    
    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Récupérer l'historique
    const history = await getUserHistory(user.id, parseInt(limit));

    res.json({
      success: true,
      history
    });
  } catch (error) {
    next(error);
  }
};

export const getAnalysesList = async (req, res, next) => {
  try {
    const { limit = 20, offset = 0 } = req.query;
    
    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Récupérer les analyses
    const analyses = await getUserAnalyses(user.id);

    // Pagination
    const paginatedAnalyses = analyses.slice(
      parseInt(offset),
      parseInt(offset) + parseInt(limit)
    );

    res.json({
      success: true,
      analyses: paginatedAnalyses,
      total: analyses.length,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (error) {
    next(error);
  }
};

export const deleteAnalysis = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Supprimer l'analyse (cascade sur les recommandations et CV générés)
    const { error } = await supabase
      .from('analyses')
      .delete()
      .eq('id', analysisId)
      .eq('user_id', user.id);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Analyse supprimée'
    });
  } catch (error) {
    next(error);
  }
};

export const getStats = async (req, res, next) => {
  try {
    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Compter les analyses
    const { count: totalAnalyses } = await supabase
      .from('analyses')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    // Compter les CV générés
    const { count: totalCVs } = await supabase
      .from('generated_cvs')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    // Récupérer la dernière analyse
    const { data: lastAnalysis } = await supabase
      .from('analyses')
      .select('created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    res.json({
      success: true,
      stats: {
        totalAnalyses: totalAnalyses || 0,
        totalCVs: totalCVs || 0,
        credits: user.credits,
        plan: user.plan,
        lastAnalysis: lastAnalysis?.created_at || null
      }
    });
  } catch (error) {
    next(error);
  }
};

import { createOrUpdateUser, getUserByClerkId } from '../services/supabaseService.js';
import clerk from '../config/clerk.js';

export const syncUser = async (req, res, next) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ error: 'userId requis' });
    }

    // Récupérer les infos utilisateur depuis Clerk
    const clerkUser = await clerk.users.getUser(userId);
    
    if (!clerkUser) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Créer ou mettre à jour l'utilisateur dans Supabase
    const user = await createOrUpdateUser(userId, {
      email: clerkUser.emailAddresses[0]?.emailAddress,
      name: `${clerkUser.firstName || ''} ${clerkUser.lastName || ''}`.trim(),
      profileImage: clerkUser.imageUrl
    });

    res.json({
      success: true,
      user
    });
  } catch (error) {
    next(error);
  }
};

export const getCurrentUser = async (req, res, next) => {
  try {
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    next(error);
  }
};

export const getUserCredits = async (req, res, next) => {
  try {
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    res.json({
      success: true,
      credits: user.credits,
      plan: user.plan
    });
  } catch (error) {
    next(error);
  }
};

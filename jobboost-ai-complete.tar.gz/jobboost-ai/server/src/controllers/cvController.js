import { optimizeCV } from '../services/openaiService.js';
import { saveGeneratedCV, generateCVComparison } from '../services/cvGeneratorService.js';
import { 
  getAnalysis, 
  createGeneratedCV, 
  getGeneratedCV,
  getUserByClerkId,
  addHistoryEntry
} from '../services/supabaseService.js';
import fs from 'fs/promises';
import path from 'path';

export const generateOptimizedCV = async (req, res, next) => {
  try {
    const { analysisId, targetJob } = req.body;
    
    if (!analysisId) {
      return res.status(400).json({ error: 'analysisId requis' });
    }

    // Récupérer l'analyse
    const analysis = await getAnalysis(analysisId);
    
    if (!analysis) {
      return res.status(404).json({ error: 'Analyse non trouvée' });
    }

    if (analysis.status !== 'completed') {
      return res.status(400).json({ 
        error: 'L\'analyse doit être terminée avant de générer un CV',
        status: analysis.status
      });
    }

    // Récupérer l'utilisateur
    const user = await getUserByClerkId(req.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    // Réponse immédiate
    res.json({
      success: true,
      message: 'Génération du CV en cours',
      analysisId: analysis.id
    });

    // Génération asynchrone
    (async () => {
      try {
        // Préparer les données originales du CV
        const originalCVData = {
          skills: analysis.skills,
          experience: analysis.experience,
          education: analysis.education
        };

        // Optimiser le CV avec OpenAI
        const optimizationResult = await optimizeCV(originalCVData, targetJob || 'poste recherché');
        
        // Générer le fichier HTML du CV optimisé
        const cvFile = await saveGeneratedCV(
          optimizationResult.optimizedCV,
          originalCVData
        );

        // Générer la comparaison
        const improvements = generateCVComparison(
          originalCVData,
          optimizationResult.optimizedCV
        );

        // Sauvegarder dans la base de données
        await createGeneratedCV(analysis.id, user.id, {
          url: cvFile.url,
          filename: cvFile.filename,
          improvements: [...improvements, ...(optimizationResult.optimizedCV.improvements || [])]
        });

        // Ajouter dans l'historique
        await addHistoryEntry(user.id, analysis.id, 'cv_generated', {
          targetJob,
          improvementsCount: improvements.length
        });

      } catch (error) {
        console.error('Error generating optimized CV:', error);
      }
    })();

  } catch (error) {
    next(error);
  }
};

export const getCVStatus = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    const generatedCV = await getGeneratedCV(analysisId);
    
    if (!generatedCV) {
      return res.json({
        success: true,
        status: 'pending',
        cv: null
      });
    }

    res.json({
      success: true,
      status: 'completed',
      cv: {
        id: generatedCV.id,
        url: generatedCV.optimized_cv_url,
        filename: generatedCV.optimized_cv_filename,
        improvements: generatedCV.improvements,
        created_at: generatedCV.created_at
      }
    });
  } catch (error) {
    next(error);
  }
};

export const downloadCV = async (req, res, next) => {
  try {
    const { filename } = req.params;
    
    const filepath = path.join('/tmp', filename);
    
    // Vérifier que le fichier existe
    try {
      await fs.access(filepath);
    } catch {
      return res.status(404).json({ error: 'Fichier non trouvé' });
    }

    // Envoyer le fichier
    res.download(filepath, filename, (err) => {
      if (err) {
        console.error('Download error:', err);
        next(err);
      }
    });
  } catch (error) {
    next(error);
  }
};

export const getComparison = async (req, res, next) => {
  try {
    const { analysisId } = req.params;
    
    const analysis = await getAnalysis(analysisId);
    const generatedCV = await getGeneratedCV(analysisId);
    
    if (!analysis || !generatedCV) {
      return res.status(404).json({ error: 'Données non trouvées' });
    }

    res.json({
      success: true,
      comparison: {
        original: {
          skills: analysis.skills,
          experience: analysis.experience,
          education: analysis.education
        },
        optimized: {
          url: generatedCV.optimized_cv_url,
          improvements: generatedCV.improvements
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

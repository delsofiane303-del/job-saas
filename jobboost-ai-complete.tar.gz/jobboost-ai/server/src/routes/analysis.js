import express from 'express';
import { 
  startAnalysis, 
  getAnalysisStatus, 
  getAnalysisResults 
} from '../controllers/analysisController.js';
import { requireAuth } from '../middleware/auth.js';
import { analysisLimiter } from '../middleware/rateLimiter.js';

const router = express.Router();

// Démarrer une analyse
router.post('/start', requireAuth, analysisLimiter, startAnalysis);

// Récupérer le statut d'une analyse
router.get('/status/:analysisId', requireAuth, getAnalysisStatus);

// Récupérer les résultats d'une analyse
router.get('/results/:analysisId', requireAuth, getAnalysisResults);

export default router;

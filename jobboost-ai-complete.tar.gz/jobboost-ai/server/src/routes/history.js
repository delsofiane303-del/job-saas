import express from 'express';
import { 
  getHistory, 
  getAnalysesList, 
  deleteAnalysis,
  getStats
} from '../controllers/historyController.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// Récupérer l'historique complet
router.get('/', requireAuth, getHistory);

// Récupérer la liste des analyses
router.get('/analyses', requireAuth, getAnalysesList);

// Supprimer une analyse
router.delete('/analyses/:analysisId', requireAuth, deleteAnalysis);

// Récupérer les statistiques
router.get('/stats', requireAuth, getStats);

export default router;

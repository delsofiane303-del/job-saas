import express from 'express';
import { upload, uploadCV, getUploadStatus } from '../controllers/uploadController.js';
import { requireAuth } from '../middleware/auth.js';
import { uploadLimiter } from '../middleware/rateLimiter.js';

const router = express.Router();

// Upload d'un CV
router.post(
  '/',
  requireAuth,
  uploadLimiter,
  upload.single('cv'),
  uploadCV
);

// Récupérer le statut d'un upload
router.get('/status/:analysisId', requireAuth, getUploadStatus);

export default router;

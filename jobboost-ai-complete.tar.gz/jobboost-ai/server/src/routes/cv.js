import express from 'express';
import { 
  generateOptimizedCV, 
  getCVStatus, 
  downloadCV,
  getComparison
} from '../controllers/cvController.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// Générer un CV optimisé
router.post('/generate', requireAuth, generateOptimizedCV);

// Récupérer le statut de génération
router.get('/status/:analysisId', requireAuth, getCVStatus);

// Télécharger un CV généré
router.get('/download/:filename', downloadCV);

// Récupérer la comparaison original vs optimisé
router.get('/comparison/:analysisId', requireAuth, getComparison);

export default router;

import express from 'express';
import { syncUser, getCurrentUser, getUserCredits } from '../controllers/authController.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// Synchroniser l'utilisateur Clerk avec Supabase
router.post('/sync', syncUser);

// Récupérer l'utilisateur actuel
router.get('/me', requireAuth, getCurrentUser);

// Récupérer les crédits de l'utilisateur
router.get('/credits', requireAuth, getUserCredits);

export default router;

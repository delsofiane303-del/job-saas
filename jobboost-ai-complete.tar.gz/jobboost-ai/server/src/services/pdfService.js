import pdf from 'pdf-parse';
import fs from 'fs/promises';

export const extractTextFromPDF = async (filePath) => {
  try {
    const dataBuffer = await fs.readFile(filePath);
    const data = await pdf(dataBuffer);
    
    // Nettoyer et formater le texte extrait
    const cleanText = data.text
      .replace(/\s+/g, ' ')
      .replace(/\n+/g, '\n')
      .trim();

    return {
      text: cleanText,
      pages: data.numpages,
      info: data.info
    };
  } catch (error) {
    console.error('Error extracting PDF text:', error);
    throw new Error('Impossible d\'extraire le texte du PDF');
  }
};

export const extractTextFromDOCX = async (filePath) => {
  try {
    // Pour DOCX, on utiliserait mammoth ou docx-parser
    // Simplifié ici pour l'exemple
    const dataBuffer = await fs.readFile(filePath);
    
    // Import dynamique pour éviter les erreurs si le package n'est pas installé
    const mammoth = await import('mammoth').catch(() => null);
    
    if (!mammoth) {
      throw new Error('Mammoth package not installed');
    }

    const result = await mammoth.extractRawText({ buffer: dataBuffer });
    
    return {
      text: result.value.trim(),
      pages: 1,
      info: {}
    };
  } catch (error) {
    console.error('Error extracting DOCX text:', error);
    throw new Error('Impossible d\'extraire le texte du DOCX');
  }
};

export const extractTextFromFile = async (filePath, mimeType) => {
  if (mimeType === 'application/pdf') {
    return await extractTextFromPDF(filePath);
  } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    return await extractTextFromDOCX(filePath);
  } else {
    throw new Error('Type de fichier non supporté');
  }
};

export const validateCV = (text) => {
  // Vérifications basiques pour s'assurer que c'est bien un CV
  const minLength = 100;
  const requiredKeywords = ['experience', 'compétence', 'formation', 'skill', 'education', 'work'];
  
  if (text.length < minLength) {
    return {
      valid: false,
      error: 'Le document semble trop court pour être un CV'
    };
  }

  const lowerText = text.toLowerCase();
  const hasRequiredKeywords = requiredKeywords.some(keyword => lowerText.includes(keyword));

  if (!hasRequiredKeywords) {
    return {
      valid: false,
      error: 'Le document ne semble pas être un CV valide'
    };
  }

  return { valid: true };
};

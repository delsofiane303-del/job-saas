import supabase from '../config/database.js';

// Users
export const createOrUpdateUser = async (clerkId, userData) => {
  const { data, error } = await supabase
    .from('users')
    .upsert({
      clerk_id: clerkId,
      email: userData.email,
      name: userData.name,
      profile_image: userData.profileImage,
      updated_at: new Date().toISOString()
    }, {
      onConflict: 'clerk_id'
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getUserByClerkId = async (clerkId) => {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('clerk_id', clerkId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

export const updateUserCredits = async (userId, credits) => {
  const { data, error } = await supabase
    .from('users')
    .update({ credits })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const decrementUserCredits = async (userId) => {
  const { data: user } = await supabase
    .from('users')
    .select('credits')
    .eq('id', userId)
    .single();

  if (!user || user.credits <= 0) {
    throw new Error('Crédits insuffisants');
  }

  const { data, error } = await supabase
    .from('users')
    .update({ credits: user.credits - 1 })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Analyses
export const createAnalysis = async (userId, fileData) => {
  const { data, error } = await supabase
    .from('analyses')
    .insert({
      user_id: userId,
      original_cv_url: fileData.url,
      original_cv_filename: fileData.filename,
      status: 'processing'
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateAnalysis = async (analysisId, updates) => {
  const { data, error } = await supabase
    .from('analyses')
    .update(updates)
    .eq('id', analysisId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getAnalysis = async (analysisId) => {
  const { data, error } = await supabase
    .from('analyses')
    .select('*')
    .eq('id', analysisId)
    .single();

  if (error) throw error;
  return data;
};

export const getUserAnalyses = async (userId) => {
  const { data, error } = await supabase
    .from('analyses')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

// Job Recommendations
export const createJobRecommendations = async (analysisId, recommendations) => {
  const records = recommendations.map(rec => ({
    analysis_id: analysisId,
    job_title: rec.title,
    compatibility_score: rec.compatibilityScore,
    average_salary: rec.averageSalary,
    required_skills: rec.requiredSkills,
    missing_skills: rec.missingSkills,
    description: rec.description
  }));

  const { data, error } = await supabase
    .from('job_recommendations')
    .insert(records)
    .select();

  if (error) throw error;
  return data;
};

export const getJobRecommendations = async (analysisId) => {
  const { data, error } = await supabase
    .from('job_recommendations')
    .select('*')
    .eq('analysis_id', analysisId)
    .order('compatibility_score', { ascending: false });

  if (error) throw error;
  return data;
};

// Generated CVs
export const createGeneratedCV = async (analysisId, userId, cvData) => {
  const { data, error } = await supabase
    .from('generated_cvs')
    .insert({
      analysis_id: analysisId,
      user_id: userId,
      optimized_cv_url: cvData.url,
      optimized_cv_filename: cvData.filename,
      improvements: cvData.improvements
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getGeneratedCV = async (analysisId) => {
  const { data, error } = await supabase
    .from('generated_cvs')
    .select('*')
    .eq('analysis_id', analysisId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

// History
export const addHistoryEntry = async (userId, analysisId, actionType, metadata = {}) => {
  const { data, error } = await supabase
    .from('history')
    .insert({
      user_id: userId,
      analysis_id: analysisId,
      action_type: actionType,
      metadata
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getUserHistory = async (userId, limit = 50) => {
  const { data, error } = await supabase
    .from('history')
    .select(`
      *,
      analyses (
        original_cv_filename,
        status,
        created_at
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
};

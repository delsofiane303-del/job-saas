import openai from '../config/openai.js';

export const analyzeCV = async (cvText) => {
  try {
    const prompt = `Tu es un expert en recrutement et en carrière. Analyse ce CV et extrais les informations suivantes au format JSON stricte:

{
  "skills": {
    "technical": ["liste des compétences techniques"],
    "soft": ["liste des soft skills"],
    "languages": ["langues parlées avec niveau"]
  },
  "experience": [
    {
      "title": "poste",
      "company": "entreprise",
      "duration": "durée",
      "description": "description courte"
    }
  ],
  "education": [
    {
      "degree": "diplôme",
      "institution": "établissement",
      "year": "année"
    }
  ],
  "summary": "résumé professionnel en 2-3 phrases"
}

CV à analyser:
${cvText}`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'Tu es un expert en analyse de CV. Réponds uniquement en JSON valide.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });

    const response = completion.choices[0].message.content;
    return JSON.parse(response);
  } catch (error) {
    console.error('Error analyzing CV:', error);
    throw new Error('Erreur lors de l\'analyse du CV');
  }
};

export const recommendJobs = async (profileData) => {
  try {
    const prompt = `Basé sur ce profil professionnel, recommande 5 métiers adaptés avec un score de compatibilité.

Profil:
${JSON.stringify(profileData, null, 2)}

Retourne un JSON avec ce format:
{
  "recommendations": [
    {
      "title": "Titre du métier",
      "compatibilityScore": 85,
      "averageSalary": "45000-60000€",
      "requiredSkills": ["compétence1", "compétence2"],
      "missingSkills": ["compétence à acquérir"],
      "description": "Description courte du métier et pourquoi c'est adapté"
    }
  ]
}`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'Tu es un conseiller en orientation professionnelle expert. Réponds uniquement en JSON valide.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.5,
      max_tokens: 2500
    });

    const response = completion.choices[0].message.content;
    return JSON.parse(response);
  } catch (error) {
    console.error('Error recommending jobs:', error);
    throw new Error('Erreur lors de la recommandation de métiers');
  }
};

export const optimizeCV = async (originalCV, targetJob) => {
  try {
    const prompt = `Optimise ce CV pour le métier cible: ${targetJob}

CV original:
${JSON.stringify(originalCV, null, 2)}

Retourne un JSON avec:
{
  "optimizedCV": {
    "summary": "nouveau résumé optimisé",
    "skills": {
      "technical": ["compétences réorganisées par priorité"],
      "soft": ["soft skills pertinentes"]
    },
    "experience": [
      {
        "title": "titre",
        "company": "entreprise",
        "duration": "durée",
        "description": "description réécrite pour mettre en valeur les compétences pertinentes",
        "highlights": ["réalisation 1", "réalisation 2"]
      }
    ],
    "education": [...],
    "improvements": [
      "Amélioration 1: description",
      "Amélioration 2: description"
    ]
  }
}`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'Tu es un expert en optimisation de CV. Réponds uniquement en JSON valide.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.4,
      max_tokens: 3000
    });

    const response = completion.choices[0].message.content;
    return JSON.parse(response);
  } catch (error) {
    console.error('Error optimizing CV:', error);
    throw new Error('Erreur lors de l\'optimisation du CV');
  }
};

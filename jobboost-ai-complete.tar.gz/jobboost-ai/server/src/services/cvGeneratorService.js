import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export const generateCVHTML = (cvData, originalData) => {
  const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Optimisé - ${cvData.name || 'Candidat'}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            background: #fff;
        }
        
        .header {
            border-bottom: 3px solid #3B82F6;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #1E293B;
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .contact-info {
            color: #64748B;
            font-size: 14px;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section-title {
            color: #3B82F6;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #E2E8F0;
        }
        
        .summary {
            font-size: 15px;
            line-height: 1.8;
            color: #475569;
        }
        
        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .skill-category h4 {
            color: #1E293B;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .skill-list {
            list-style: none;
        }
        
        .skill-list li {
            padding: 4px 0;
            color: #64748B;
            font-size: 13px;
        }
        
        .skill-list li:before {
            content: "▹";
            color: #3B82F6;
            font-weight: bold;
            margin-right: 8px;
        }
        
        .experience-item, .education-item {
            margin-bottom: 20px;
        }
        
        .job-title {
            font-size: 16px;
            font-weight: 600;
            color: #1E293B;
        }
        
        .company {
            color: #3B82F6;
            font-size: 14px;
            margin: 4px 0;
        }
        
        .duration {
            color: #64748B;
            font-size: 13px;
            font-style: italic;
        }
        
        .description {
            margin-top: 8px;
            color: #475569;
            font-size: 14px;
        }
        
        .highlights {
            list-style: none;
            margin-top: 10px;
        }
        
        .highlights li {
            padding: 4px 0;
            color: #475569;
            font-size: 13px;
            padding-left: 20px;
            position: relative;
        }
        
        .highlights li:before {
            content: "✓";
            color: #3B82F6;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        
        @media print {
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>${cvData.name || originalData.name || 'Nom du candidat'}</h1>
        <div class="contact-info">
            ${cvData.email || originalData.email || ''} ${cvData.phone ? '• ' + cvData.phone : ''} ${cvData.location ? '• ' + cvData.location : ''}
        </div>
    </div>

    ${cvData.summary ? `
    <div class="section">
        <h2 class="section-title">Résumé Professionnel</h2>
        <p class="summary">${cvData.summary}</p>
    </div>
    ` : ''}

    ${cvData.skills ? `
    <div class="section">
        <h2 class="section-title">Compétences</h2>
        <div class="skills-grid">
            ${cvData.skills.technical ? `
            <div class="skill-category">
                <h4>Compétences Techniques</h4>
                <ul class="skill-list">
                    ${cvData.skills.technical.map(skill => `<li>${skill}</li>`).join('')}
                </ul>
            </div>
            ` : ''}
            
            ${cvData.skills.soft ? `
            <div class="skill-category">
                <h4>Soft Skills</h4>
                <ul class="skill-list">
                    ${cvData.skills.soft.map(skill => `<li>${skill}</li>`).join('')}
                </ul>
            </div>
            ` : ''}
            
            ${cvData.skills.languages ? `
            <div class="skill-category">
                <h4>Langues</h4>
                <ul class="skill-list">
                    ${cvData.skills.languages.map(lang => `<li>${lang}</li>`).join('')}
                </ul>
            </div>
            ` : ''}
        </div>
    </div>
    ` : ''}

    ${cvData.experience && cvData.experience.length > 0 ? `
    <div class="section">
        <h2 class="section-title">Expérience Professionnelle</h2>
        ${cvData.experience.map(exp => `
        <div class="experience-item">
            <div class="job-title">${exp.title}</div>
            <div class="company">${exp.company}</div>
            <div class="duration">${exp.duration}</div>
            <div class="description">${exp.description}</div>
            ${exp.highlights && exp.highlights.length > 0 ? `
            <ul class="highlights">
                ${exp.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
            </ul>
            ` : ''}
        </div>
        `).join('')}
    </div>
    ` : ''}

    ${cvData.education && cvData.education.length > 0 ? `
    <div class="section">
        <h2 class="section-title">Formation</h2>
        ${cvData.education.map(edu => `
        <div class="education-item">
            <div class="job-title">${edu.degree}</div>
            <div class="company">${edu.institution}</div>
            <div class="duration">${edu.year}</div>
        </div>
        `).join('')}
    </div>
    ` : ''}
</body>
</html>
  `;
  
  return html;
};

export const saveGeneratedCV = async (cvData, originalData) => {
  try {
    const html = generateCVHTML(cvData, originalData);
    const filename = `cv_optimized_${uuidv4()}.html`;
    const filepath = path.join('/tmp', filename);
    
    await fs.writeFile(filepath, html, 'utf-8');
    
    return {
      filename,
      filepath,
      url: `/api/cv/download/${filename}`
    };
  } catch (error) {
    console.error('Error saving generated CV:', error);
    throw new Error('Erreur lors de la sauvegarde du CV généré');
  }
};

export const generateCVComparison = (originalCV, optimizedCV) => {
  const improvements = [];
  
  // Comparer les résumés
  if (optimizedCV.summary && (!originalCV.summary || optimizedCV.summary !== originalCV.summary)) {
    improvements.push({
      type: 'summary',
      before: originalCV.summary || 'Aucun résumé',
      after: optimizedCV.summary,
      description: 'Résumé professionnel optimisé pour mettre en valeur vos atouts'
    });
  }
  
  // Comparer les compétences
  if (optimizedCV.skills) {
    const techSkillsAdded = optimizedCV.skills.technical?.filter(
      skill => !originalCV.skills?.technical?.includes(skill)
    ) || [];
    
    if (techSkillsAdded.length > 0) {
      improvements.push({
        type: 'skills',
        description: `${techSkillsAdded.length} compétences techniques mises en avant`,
        details: techSkillsAdded
      });
    }
  }
  
  // Comparer l'expérience
  if (optimizedCV.experience && originalCV.experience) {
    const experienceImprovements = optimizedCV.experience.filter((exp, idx) => {
      const original = originalCV.experience[idx];
      return original && (
        exp.description !== original.description ||
        (exp.highlights && exp.highlights.length > 0)
      );
    });
    
    if (experienceImprovements.length > 0) {
      improvements.push({
        type: 'experience',
        description: `${experienceImprovements.length} expériences professionnelles reformulées`,
        details: experienceImprovements.map(exp => exp.title)
      });
    }
  }
  
  return improvements;
};

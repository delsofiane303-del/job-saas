import rateLimit from 'express-rate-limit';

// Rate limiter général pour les API
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: 'Trop de requêtes depuis cette IP, veuillez réessayer plus tard.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter strict pour les uploads
export const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 10,
  message: 'Trop d\'uploads, veuillez réessayer dans une heure.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limiter pour les analyses IA
export const analysisLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 5,
  message: 'Limite d\'analyses atteinte, veuillez réessayer dans une heure.',
  standardHeaders: true,
  legacyHeaders: false,
});

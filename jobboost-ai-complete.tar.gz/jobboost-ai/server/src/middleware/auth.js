import clerk from '../config/clerk.js';

export const requireAuth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Token manquant' });
    }

    // Vérifier le token avec Clerk
    const session = await clerk.sessions.verifySession(token);
    
    if (!session) {
      return res.status(401).json({ error: 'Session invalide' });
    }

    // Ajouter l'utilisateur à la requête
    req.userId = session.userId;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ error: 'Authentification échouée' });
  }
};

export const optionalAuth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (token) {
      const session = await clerk.sessions.verifySession(token);
      if (session) {
        req.userId = session.userId;
      }
    }
    next();
  } catch (error) {
    next();
  }
};

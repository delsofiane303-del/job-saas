export const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);

  // Erreur de validation
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Erreur de validation',
      details: err.message
    });
  }

  // Erreur Multer (upload)
  if (err.name === 'MulterError') {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'Fichier trop volumineux',
        details: 'La taille maximale est de 10 Mo'
      });
    }
    return res.status(400).json({
      error: 'Erreur d\'upload',
      details: err.message
    });
  }

  // Erreur OpenAI
  if (err.name === 'OpenAIError') {
    return res.status(503).json({
      error: 'Service IA temporairement indisponible',
      details: 'Veuillez réessayer dans quelques instants'
    });
  }

  // Erreur Supabase
  if (err.code && err.code.startsWith('PGRST')) {
    return res.status(500).json({
      error: 'Erreur de base de données',
      details: 'Une erreur est survenue lors de l\'accès aux données'
    });
  }

  // Erreur générique
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    error: err.message || 'Erreur interne du serveur',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

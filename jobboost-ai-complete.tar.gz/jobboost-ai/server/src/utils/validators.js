export const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validateFileType = (mimetype) => {
  const allowedTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];
  return allowedTypes.includes(mimetype);
};

export const validateFileSize = (size, maxSize = 10 * 1024 * 1024) => {
  return size <= maxSize;
};

export const validateUUID = (uuid) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

export const sanitizeFilename = (filename) => {
  return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
};

export const validateAnalysisData = (data) => {
  const errors = [];

  if (!data.skills || typeof data.skills !== 'object') {
    errors.push('Skills manquantes ou invalides');
  }

  if (!data.experience || !Array.isArray(data.experience)) {
    errors.push('Experience manquante ou invalide');
  }

  if (!data.education || !Array.isArray(data.education)) {
    errors.push('Education manquante ou invalide');
  }

  return {
    valid: errors.length === 0,
    errors
  };
};
